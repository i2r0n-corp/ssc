/**
 * SSC Catalog Intelligence — Single Page Application
 * Pure JavaScript (no build step required for development)
 * Uses SAP UI5 Web Components loaded from CDN or public assets
 */

// ── Configuration ─────────────────────────────────────────────────────────────
const CAP_BACKEND_URL = window.CAP_BACKEND_URL || 'http://localhost:4004';
const AGENT_BASE_URL  = window.AGENT_BASE_URL  || 'http://localhost:5000';

// ── State ─────────────────────────────────────────────────────────────────────
let state = {
  currentPage: 'catalog',
  catalog: { services: [], lastUpdated: null, loading: false, error: null },
  filters: { query: '', engagementType: '', businessScenario: '', module: '', modules: [], phases: [], phaseMode: 'merge', supercats: [], advancedLoS: [], advancedLoSMode: 'merge', foundationalCats: [], foundationalCatsMode: 'merge', maxFocusTopics: [], maxFocusTopicsMode: 'merge', deckName: '', namingType: '', etLabelType: 'engagement' },
  filteredServices: [],
  exportCart: JSON.parse(sessionStorage.getItem('exportCart') || '[]'),
  filtersExpanded: false,
  debug: { bsCode: '', module: '', serviceName: '', status: '', rows: [], totals: null, loading: false, error: null, selectedRow: null },
  selectedServices: new Set(),
  serviceDetail: null,
  incident: { file: null, results: [], loading: false, error: null, selectedCodes: new Set() },
  pptx: { template: 'short-description', generating: false, error: null, downloadUrl: null },
  sort: { col: null, dir: 'asc' },
  pptxListSettings: {
    open: false,
    cols: { stream: true, phases: true, component: true, tier: false, objectives: true, pd: false },
    years: false, yearFrom: '2026', yearTo: '2030', yearBorders: false,
    groupByET: false, useDeckName: false,
    title: 'Services Description',
    streamMode: 'bsAndModule',
    streamCustom: '',
    truncateObjectives: false,
    switchTypes: false,
  },
  excelSettings: {
    open: false,
    pdMode: false,
    yearFrom: '2026', yearTo: '2030',
  },
  chat: { messages: [], loading: false, input: '' },
  exportLog: { rows: [], loading: false, error: null, loaded: false, selectedRow: null, sortCol: 'logged_at', sortDir: 'desc' },
  currentUser: null,
  myPermissions: { catalog: true, incidents: false, chat: false, debug: false, exportlog: false, admin: false },
  admin: { users: [], usersLoading: false, usersError: null, newEmail: '', visitorLog: [], visitorLastSeen: [], visitorLoading: false, visitorError: null, mcpRequests: [], mcpRequestsLoading: false, mcpRequestsError: null, mcpOpenCollapsed: false, selectedVisitorUser: null, visitSortCol: 'visited_at', visitSortDir: 'desc', selectedVisit: null },
  mcpModal: { open: false, sent: false, sending: false, error: null },
  accessDeniedModal: false,
  backendDown: false,
  exportTotal: null,
  sessionId: Math.random().toString(36).slice(2),
};

function saveCart() {
  sessionStorage.setItem('exportCart', JSON.stringify(state.exportCart));
}

// ── API helpers ───────────────────────────────────────────────────────────────
async function apiFetch(url, options = {}) {
  const res = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...options });
  if (!res.ok) throw new Error(`API error ${res.status}: ${await res.text()}`);
  return res.json();
}

async function loadCatalog() {
  state.catalog.loading = true; render();
  try {
    // Load only metadata — BS list, module list, engagement types
    // Do NOT download full snapshot to browser
    const data = await apiFetch(`${CAP_BACKEND_URL}/api/catalog/metadata`);

    state.catalog.bsMap = data.bsMap || {};
    state.catalog.moduleMap = data.moduleMap || {};
    state.catalog.bsToMods = data.bsToMods || {};
    state.catalog.bsUrlMap = data.bsUrlMap || {};
    state.catalog.engagementTypes = data.engagementTypes || [];
    state.catalog.phases = data.phases || [];
    state.catalog.supercategories = data.supercategories || [];
    state.catalog.maxFocusTopics = data.maxFocusTopics || [];
    state.catalog.foundationalCatsWithServices = data.foundationalCatsWithServices || [];
    state.catalog.lastUpdated = data.lastUpdated;
    state.catalog.serviceCount = data.serviceCount;
    state.catalog.services = []; // not loaded upfront
    state.filteredServices = [];
    state.catalog.hasSearched = false;
    state.catalog.error = null;
  } catch (e) {
    if (e instanceof TypeError && e.message.toLowerCase().includes('fetch')) {
      state.backendDown = true;
    } else {
      state.catalog.error = e.message;
    }
  }
  state.catalog.loading = false; render();
}

function patchResults() {
  const el = document.getElementById('catalog-results');
  if (el) el.innerHTML = renderCatalogResults();
  else render();
}

function patchCounts() {
  const { phases = {}, supercats = {}, maxTopics = {} } = state.catalog.filterCounts || {};
  document.querySelectorAll('[data-cnt]').forEach(el => {
    const { cnt: key, cntmap: map } = el.dataset;
    const counts = map === 'phase' ? phases : map === 'super' ? supercats : maxTopics;
    el.textContent = '(' + (counts[key] || 0) + ')';
  });
}

function patchFilters() {
  const el = document.getElementById('catalog-filters');
  if (!el) { render(); return; }
  const sy = window.scrollY;
  el.innerHTML = renderCatalogFilters();
  requestAnimationFrame(() => window.scrollTo({ top: sy, behavior: 'instant' }));
}

async function applyFilters() {
  const { query, engagementType, businessScenario, module: mod } = state.filters;
  const mods            = state.filters.modules       || [];
  const phases          = state.filters.phases        || [];
  const phaseMode       = state.filters.phaseMode      || 'merge';
  const supercats       = state.filters.supercats     || [];
  const advancedLoS     = state.filters.advancedLoS   || [];
  const advancedLoSMode = state.filters.advancedLoSMode || 'merge';
  const foundationalCats = state.filters.foundationalCats || [];
  const foundationalCatsMode = state.filters.foundationalCatsMode || 'merge';
  const maxFocusTopics  = state.filters.maxFocusTopics || [];
  const maxFocusTopicsMode = state.filters.maxFocusTopicsMode || 'merge';

  // Combine foundational supercats and keep advancedLoS separate for mode handling
  const allSupercats = [...new Set([...supercats])];

  // Nothing selected — clear results and show prompt
  if (!query && !engagementType && !businessScenario && !mod && mods.length === 0 && phases.length === 0 && allSupercats.length === 0 && advancedLoS.length === 0 && foundationalCats.length === 0 && maxFocusTopics.length === 0) {
    state.filteredServices = [];
    state.catalog.hasSearched = false;
    computeFilterCounts();
    patchResults();
    patchCounts();
    return;
  }

  state.catalog.hasSearched = true;
  state.catalog.loading = true; patchResults();

  try {
    // Build query params for server-side filtering
    const params = new URLSearchParams();
    if (query) params.set('query', query);
    if (engagementType) params.set('engagementType', engagementType);
    if (businessScenario) params.set('businessScenario', businessScenario);
    // multi-module support
    if (mods.length > 0) mods.forEach(m => params.append('module', m));
    else if (mod) params.set('module', mod);
    // phases
    phases.forEach(p => params.append('phase', p));
    if (phases.length > 0) params.set('phaseMode', phaseMode);
    // plain supercats (always OR union)
    allSupercats.forEach(s => params.append('supercat', s));
    // advanced LoS — sent separately so the backend can apply the right mode
    advancedLoS.forEach(s => params.append('advancedLoSCat', s));
    if (advancedLoS.length > 0) params.set('advancedLoSMode', advancedLoSMode);
    // foundational cats — sent separately so the backend can apply the right mode
    foundationalCats.forEach(s => params.append('foundationalCat', s));
    if (foundationalCats.length > 0) params.set('foundationalCatsMode', foundationalCatsMode);
    // max focus topics
    maxFocusTopics.forEach(t => params.append('maxFocusTopic', t));
    if (maxFocusTopics.length > 0) params.set('maxFocusTopicsMode', maxFocusTopicsMode);

    const url = query
      ? `${CAP_BACKEND_URL}/api/catalog/searchServices?${params}`
      : `${CAP_BACKEND_URL}/api/catalog/filterServices?${params}`;

    const data = await apiFetch(url);
    state.filteredServices = data.services || [];
  } catch (e) {
    state.filteredServices = [];
  }
  state.catalog.loading = false;
  computeFilterCounts();
  patchResults();
  patchCounts();
}

function computeFilterCounts() {
  const svcs = state.filteredServices;
  const phases = {}, supercats = {}, maxTopics = {}, etCounts = { max: 0, advanced: 0, foundational: 0 };
  svcs.forEach(svc => {
    (svc.classificationFeatures || []).forEach(f => {
      const vals = Array.isArray(f.value) ? f.value : [f.value];
      if (f.key === 'sapActivateProjectPhase') {
        vals.forEach(v => { if (v) phases[v] = (phases[v] || 0) + 1; });
      } else if (f.key === 'maxFocusTopic') {
        vals.forEach(v => { if (v) maxTopics[v] = (maxTopics[v] || 0) + 1; });
      }
    });
    (svc.supercategories || []).forEach(c => {
      const n = typeof c === 'string' ? c : (c.name || '');
      if (n) supercats[n] = (supercats[n] || 0) + 1;
    });
    const ets = Array.isArray(svc.engagementType) ? svc.engagementType : (svc.engagementType ? [svc.engagementType] : []);
    ets.forEach(e => {
      if (e === 'Max Success Plan') etCounts.max++;
      else if (e === 'Advanced Success Plan') etCounts.advanced++;
      else if (e === 'Enterprise Support') etCounts.foundational++;
    });
  });
  state.catalog.filterCounts = { phases, supercats, maxTopics, etCounts };
}

// ── ET display mapping ────────────────────────────────────────────────────────
// "Enterprise Support" → displayed as "Foundational" everywhere in results
function mapEtDisplay(val) {
  if (!val) return val;
  if (state.filters.etLabelType === 'service') {
    if (val === 'Max Success Plan') return 'Premium Service';
    if (val === 'Advanced Success Plan' || val === 'Enterprise Support') return 'Service Entitlement';
    return val;
  }
  return val === 'Enterprise Support' ? 'Foundational' : val;
}

// ── Engagement type badge ─────────────────────────────────────────────────────
function engagementBadge(et) {
  let arr = Array.isArray(et) ? et : (et ? [et] : []);
  if (arr.length === 0) return '—';
  const activeET = state.filters.engagementType;
  if (activeET) {
    // ET filter active — show only that ET's badge
    arr = arr.includes(activeET) ? [activeET] : arr;
  } else if (arr.length > 1) {
    // No ET filter — show only the base/foundational ET to avoid multi-badge clutter
    const priority = ['Enterprise Support', 'Advanced Success Plan', 'Max Success Plan'];
    const base = priority.find(p => arr.includes(p));
    if (base) arr = [base];
  }
  return arr.map(val => {
    const display = mapEtDisplay(val);
    const cls = val === 'Max Success Plan' ? 'badge-max' : val === 'Advanced Success Plan' ? 'badge-adv' : 'badge-ent';
    return `<span class="badge ${cls}">${display}</span>`;
  }).join(' ');
}

// ── Pages ─────────────────────────────────────────────────────────────────────

function renderCatalogFilters() {
  const { error, moduleMap = {}, bsMap = {}, phases = [], supercategories = [], maxFocusTopics: allMaxTopics = [], foundationalCatsWithServices = [] } = state.catalog;

  const { phases: phaseCounts = {}, supercats: superCounts = {}, maxTopics: maxTopicCounts = {} } = state.catalog.filterCounts || {};
  const cnt = (map, key, mapname) => {
    const n = map[key] || 0;
    return ` <span data-cnt="${key.replace(/"/g,'&quot;')}" data-cntmap="${mapname}" style="font-size:0.7rem;color:#8696A9;font-weight:400">(${n})</span>`;
  };

  const ET_OPTIONS = [
    { value: 'Max Success Plan',      label: 'Max Success Plan' },
    { value: 'Advanced Success Plan', label: 'Advanced Success Plan' },
    { value: 'Enterprise Support',    label: 'Foundational Success Plan' },
  ];

  const uniqueBS = Object.entries(bsMap)
    .map(([code, name]) => {
      const label = name.includes('-') ? name.replace(/^[^-]+-\s*/, '') : name;
      return [code, name, label];
    })
    .sort((a, b) => a[0].localeCompare(b[0]));

  const showModuleFilter = !!state.filters.businessScenario;
  let uniqueMods = [];
  if (showModuleFilter) {
    const bsToMods = state.catalog.bsToMods || {};
    const modCodes = bsToMods[state.filters.businessScenario] || [];
    uniqueMods = modCodes
      .filter(code => moduleMap[code])
      .map(code => [code, moduleMap[code]])
      .sort((a, b) => a[1].localeCompare(b[1]));
  }

  const selectedMods = state.filters.modules || [];
  const et = state.filters.engagementType;
  const queryOrBS = !!(state.filters.query || state.filters.businessScenario);

  const activatePhaseActive  = queryOrBS;
  const maxTopicsActive      = (queryOrBS || et === 'Max Success Plan')      && et !== 'Advanced Success Plan' && et !== 'Enterprise Support';
  const advancedActive       = (queryOrBS || et === 'Advanced Success Plan') && et !== 'Max Success Plan'      && et !== 'Enterprise Support';
  const foundationalActive   = (queryOrBS || et === 'Enterprise Support')    && et !== 'Max Success Plan'      && et !== 'Advanced Success Plan';
  const disabledStyle = 'opacity:0.4;pointer-events:none';

  const advancedLoSItems  = supercategories.filter(s => s.startsWith('Success Plans for'));
  const foundationalItems = supercategories.filter(s => !s.startsWith('Success Plans for') && (foundationalCatsWithServices.length === 0 || foundationalCatsWithServices.includes(s)));

  const showAdvancedBadge     = et === 'Advanced Success Plan';
  const showFoundationalBadge = et === 'Enterprise Support';
  const showMaxBadge          = et === 'Max Success Plan';

  const namingDisabled = et === 'Max Success Plan' || !state.filters.businessScenario;
  const namingStyle    = namingDisabled ? disabledStyle : '';
  const namingActive   = !namingDisabled && !!state.filters.businessScenario;

  return `
    ${error ? `<div class="error-strip">⚠ ${error}</div>` : ''}
    <div class="filter-row" style="flex-direction:column;gap:0;padding:0">

      <!-- Two-column top area -->
      <div class="filter-columns">

        <!-- Left column: BS + hr + Keywords + ET -->
        <div class="filter-col-left">
          <!-- BS field: native select + external link button -->
          <div style="display:flex;align-items:flex-end;gap:0.4rem">
            <div class="fl-field" style="flex:1;min-width:0">
              <select id="filter-bs" ${!state.filters.businessScenario ? 'data-empty="true"' : ''}
                onchange="updateFilter('businessScenario', this.value); this.dataset.empty = this.value ? 'false' : 'true'">
                <option value=""></option>
                ${uniqueBS.map(([code,,label]) => `<option value="${code}" ${state.filters.businessScenario===code?'selected':''}>${label}</option>`).join('')}
              </select>
              <label>Business Scenario</label>
            </div>
            ${(() => {
              const bsUrl = state.filters.businessScenario ? (state.catalog.bsUrlMap||{})[state.filters.businessScenario] : null;
              return bsUrl
                ? `<a href="${bsUrl}" target="_blank" rel="noopener" title="Open in Service Catalog"
                    style="flex-shrink:0;display:flex;align-items:center;justify-content:center;width:2.25rem;height:2.25rem;background:#0070F2;border-radius:4px;text-decoration:none;margin-bottom:0"><img src="url.svg" style="height:15px;width:auto" alt="" /></a>`
                : `<span title="Open in Service Catalog"
                    style="flex-shrink:0;display:flex;align-items:center;justify-content:center;width:2.25rem;height:2.25rem;background:#d0d0d0;border-radius:4px;cursor:default;margin-bottom:0"><img src="url.svg" style="height:15px;width:auto" alt="" /></span>`;
            })()}
          </div>

          <hr style="border:none;border-top:1px solid #e0e0e0;margin:0.75rem 0" />

          <div style="display:flex;gap:1rem">
            <div class="fl-field" style="flex:1;min-width:0">
              <input type="search" id="filter-query" placeholder=" " value="${state.filters.query}"
                oninput="updateFilter('query', this.value)" />
              <label>Search by keywords</label>
            </div>
            <div class="fl-field" style="flex:1;min-width:0">
              <select id="filter-et" ${!state.filters.engagementType ? 'data-empty="true"' : ''}
                onchange="updateFilter('engagementType', this.value); this.dataset.empty = this.value ? 'false' : 'true'">
                <option value=""></option>
                ${ET_OPTIONS.map(o => `<option value="${o.value}" ${state.filters.engagementType===o.value?'selected':''}>${o.label}</option>`).join('')}
              </select>
              <label>Engagement Type</label>
            </div>
          </div>
        </div>

        <!-- Right column: Module (only when BS selected) -->
        ${showModuleFilter ? `
        <div class="filter-col-right">
          <!-- Module label + clear -->
          <div style="display:flex;align-items:center;gap:6px">
            <div style="font-size:0.75rem;color:#6a6a6a;font-weight:600;flex:1">Module</div>
            ${selectedMods.length > 0 ? `<button class="mode-switch-clear" title="Clear modules" onclick="updateCheckboxFilter._clearKey('modules')">✕</button>` : ''}
          </div>
          <!-- Module checkboxes -->
          <div class="check-panel" style="flex:1;max-height:6.6rem">
            ${uniqueMods.map(([code, name]) => {
              const label = name.includes(' // ') ? name.split(' // ').slice(1).join(' // ') : name;
              return `<label>
                <input type="checkbox" value="${code}" ${selectedMods.includes(code)?'checked':''}
                  onchange="updateCheckboxFilter('modules', '${code}', this.checked)" />
                ${label}
              </label>`;
            }).join('')}
          </div>
        </div>` : ''}
      </div>

      <!-- Divider + More filters toggle (mobile only) -->
      <button class="filter-more-btn" onclick="toggleMoreFilters()">
        ${state.filtersExpanded ? '▲ Less filters' : '▼ More filters'}
      </button>

      <!-- Section 3: 4 checkbox filters -->
      <div class="filter-sec3 ${state.filtersExpanded ? 'expanded' : ''}">

        ${phases.length > 0 ? `
        <div class="filter-group" style="${activatePhaseActive ? '' : disabledStyle}">
          <label>Activate Phases</label>
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">
            <div class="icon-switch">
              <button class="${(state.filters.phaseMode||'merge')==='merge'?'active':''}" onclick="updateFilter('phaseMode','merge')" ${(state.filters.phases||[]).length < 2 ? 'disabled' : ''}><img src="merge.svg" alt="Merge" /></button>
              <button class="${state.filters.phaseMode==='intersect'?'active':''}" onclick="updateFilter('phaseMode','intersect')" ${(state.filters.phases||[]).length < 2 ? 'disabled' : ''}><img src="intersect.svg" alt="Intersect" /></button>
            </div>
            ${(state.filters.phases||[]).length > 0 ? `<button class="mode-switch-clear" title="Clear" onclick="updateCheckboxFilter._clearKey('phases')">✕</button>` : ''}
          </div>
          <div class="check-panel">
            ${[...phases].sort((a,b) => {
              const ORDER = ['Prepare','Discover','Explore','Realize','Deploy','Run'];
              const ai = ORDER.indexOf(a), bi = ORDER.indexOf(b);
              return (ai===-1?99:ai) - (bi===-1?99:bi);
            }).map(p => `<label>
              <input type="checkbox" value="${p}" ${(state.filters.phases||[]).includes(p)?'checked':''}
                onchange="updateCheckboxFilter('phases', '${p}', this.checked)" />
              ${p}${cnt(phaseCounts, p, 'phase')}</label>`).join('')}
          </div>
        </div>` : ''}

        ${allMaxTopics.length > 0 ? `
        <div class="filter-group" style="${maxTopicsActive ? '' : disabledStyle}">
          <label>Max Focus Topics${showMaxBadge ? '' : ' <span style="font-size:0.65rem;color:#8696A9;font-weight:400">(Max)</span>'}</label>
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px;min-height:1.6rem">
            ${(state.filters.maxFocusTopics||[]).length > 0 ? `<button class="mode-switch-clear" title="Clear" onclick="updateCheckboxFilter._clearKey('maxFocusTopics')">✕</button>` : ''}
          </div>
          <div class="check-panel">
            ${allMaxTopics.map(t => `<label>
              <input type="checkbox" value="${t}" ${(state.filters.maxFocusTopics||[]).includes(t)?'checked':''}
                onchange="updateCheckboxFilter('maxFocusTopics', '${t.replace(/'/g,"\\'")}', this.checked)" />
              ${t}${cnt(maxTopicCounts, t, 'maxTopic')}</label>`).join('')}
          </div>
        </div>` : ''}

        ${advancedLoSItems.length > 0 ? `
        <div class="filter-group" style="${advancedActive ? '' : disabledStyle}">
          <label>Advanced LoB${showAdvancedBadge ? '' : ' <span style="font-size:0.65rem;color:#8696A9;font-weight:400">(Advanced)</span>'}</label>
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">
            <div class="icon-switch">
              <button class="${(state.filters.advancedLoSMode||'merge')==='merge'?'active':''}" onclick="updateFilter('advancedLoSMode','merge')" ${(state.filters.advancedLoS||[]).length < 2 ? 'disabled' : ''}><img src="merge.svg" alt="Merge" /></button>
              <button class="${state.filters.advancedLoSMode==='intersect'?'active':''}" onclick="updateFilter('advancedLoSMode','intersect')" ${(state.filters.advancedLoS||[]).length < 2 ? 'disabled' : ''}><img src="intersect.svg" alt="Intersect" /></button>
            </div>
            ${(state.filters.advancedLoS||[]).length > 0 ? `<button class="mode-switch-clear" title="Clear" onclick="updateCheckboxFilter._clearKey('advancedLoS')">✕</button>` : ''}
          </div>
          <div class="check-panel">
            ${advancedLoSItems.map(s => `<label>
              <input type="checkbox" value="${s}" ${(state.filters.advancedLoS||[]).includes(s)?'checked':''}
                onchange="updateCheckboxFilter('advancedLoS', '${s.replace(/'/g,"\\'")}', this.checked)" />
              ${s.replace('Success Plans for ', '')}${cnt(superCounts, s, 'super')}</label>`).join('')}
          </div>
        </div>` : ''}

        ${foundationalItems.length > 0 ? `
        <div class="filter-group" style="${foundationalActive ? '' : disabledStyle}">
          <label>Foundation subcategories${showFoundationalBadge ? '' : ' <span style="font-size:0.65rem;color:#8696A9;font-weight:400">(Foundation)</span>'}</label>
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">
            <div class="icon-switch">
              <button class="${(state.filters.foundationalCatsMode||'merge')==='merge'?'active':''}" onclick="updateFilter('foundationalCatsMode','merge')" ${(state.filters.foundationalCats||[]).length < 2 ? 'disabled' : ''}><img src="merge.svg" alt="Merge" /></button>
              <button class="${state.filters.foundationalCatsMode==='intersect'?'active':''}" onclick="updateFilter('foundationalCatsMode','intersect')" ${(state.filters.foundationalCats||[]).length < 2 ? 'disabled' : ''}><img src="intersect.svg" alt="Intersect" /></button>
            </div>
            ${(state.filters.foundationalCats||[]).length > 0 ? `<button class="mode-switch-clear" title="Clear" onclick="updateCheckboxFilter._clearKey('foundationalCats')">✕</button>` : ''}
          </div>
          <div class="check-panel">
            ${foundationalItems.map(s => `<label>
              <input type="checkbox" value="${s}" ${(state.filters.foundationalCats||[]).includes(s)?'checked':''}
                onchange="updateCheckboxFilter('foundationalCats', '${s.replace(/'/g,"\\'")}', this.checked)" />
              ${s}${cnt(superCounts, s, 'super')}</label>`).join('')}
          </div>
        </div>` : ''}

        <button class="btn btn-secondary btn-sm" style="align-self:flex-end;margin-left:auto" onclick="clearFilters()">Clear</button>
      </div>
    </div>`;
}

function renderCatalogPage() {
  const { lastUpdated } = state.catalog;
  return `
    <div style="display:flex;align-items:baseline;justify-content:space-between;margin-bottom:0.5rem">
      <h2 style="margin:0">Catalogue Browser</h2>
      ${lastUpdated ? `<span class="last-updated">Last updated: ${new Date(lastUpdated).toLocaleString()}</span>` : ''}
    </div>
    <div id="catalog-filters">${renderCatalogFilters()}</div>
    <div id="catalog-results">${renderCatalogResults()}</div>`;
}

function renderCatalogResults() {
  const { loading } = state.catalog;
  const hasSearched = state.catalog.hasSearched;
  const et = state.filters.engagementType;
  const bsSelected = !!state.filters.businessScenario && et !== 'Max Success Plan';
  const showEffort = !et || et === 'Max Success Plan';
  return `
    ${loading ? '<div class="loading"><div class="loading-spinner"></div> Loading...</div>' : ''}
    ${!hasSearched && !loading ? `
      <div class="empty-state">
        <div style="font-size:2.5rem">🔍</div>
        <p style="font-size:1rem;font-weight:600">Use the filters above to explore the catalog</p>
        <p style="font-size:0.875rem">Search by keyword, select an Engagement Type, Business Scenario, or Module to get started.</p>
      </div>` : !loading && state.filteredServices.length === 0 ? `
      <div class="empty-state">
        <div style="font-size:2rem">😕</div>
        <p>No services found. Try adjusting your filters.</p>
      </div>` : !loading ? `
    <div style="display:flex;gap:0.5rem;margin-bottom:0.75rem;align-items:center;flex-wrap:wrap">
      <span class="results-info" style="margin:0;flex:1;display:flex;align-items:center;gap:0.4rem;flex-wrap:wrap">
        ${(() => {
          const { etCounts = { max: 0, advanced: 0, foundational: 0 } } = state.catalog.filterCounts || {};
          const total = state.filteredServices.length;
          const isService = state.filters.etLabelType === 'service';
          const pills = [];
          if (etCounts.max > 0)         pills.push(`<span class="badge badge-max">${isService ? 'Premium' : 'Max'} — ${etCounts.max}</span>`);
          if (isService) {
            const svcEnt = etCounts.advanced + etCounts.foundational;
            if (svcEnt > 0) pills.push(`<span class="badge badge-adv">Service Entitlement — ${svcEnt}</span>`);
          } else {
            if (etCounts.advanced > 0)    pills.push(`<span class="badge badge-adv">Advanced — ${etCounts.advanced}</span>`);
            if (etCounts.foundational > 0) pills.push(`<span class="badge badge-ent">Foundational — ${etCounts.foundational}</span>`);
          }
          return `${pills.join('')}<span style="font-size:0.8rem;color:#6a6a6a">overall: <strong>${total}</strong></span>`;
        })()}
        ${state.selectedServices.size > 0 ? `<span style="font-size:0.8rem;color:#6a6a6a"> — <strong>${state.selectedServices.size} selected</strong></span>` : ''}
        ${state.pptx.downloadUrl ? `<span id="pptx-dl-msg" style="margin-left:0.75rem;color:#155724;font-weight:600">Successfully downloaded</span>` : ''}
      </span>
      <button class="btn btn-primary btn-sm" onclick="openExcelSettings()" title="Export to Excel" style="display:inline-flex;align-items:center;gap:5px">
        <img src="excel.svg" style="height:18px;width:auto" alt="" />Export to Excel ${state.selectedServices.size > 0 ? `(${state.selectedServices.size})` : '(all)'}
      </button>
      <button class="btn btn-primary btn-sm" onclick="openPptxListSettings()" title="Service list PPTX (template-based)" style="display:inline-flex;align-items:center;gap:5px">
        <img src="pptx.svg" style="height:18px;width:auto" alt="" />Export to PowerPoint ${state.selectedServices.size > 0 ? `(${state.selectedServices.size})` : '(all)'}
      </button>
      <div style="display:none">
        <button class="btn btn-primary btn-sm" disabled style="opacity:0.45;cursor:not-allowed">
          📄 PPTX One-Pagers
        </button>
      </div>
    </div>
    ${state.pptx.error ? `<div class="error-strip" style="margin-bottom:0.5rem">⚠ ${state.pptx.error}</div>` : ''}
    <table class="service-table">
      <thead>
        <tr>
          <th style="width:2.5rem"><input type="checkbox" title="Select all / deselect all"
            ${state.filteredServices.length > 0 && state.filteredServices.every(s => state.selectedServices.has(s.code)) ? 'checked' : ''}
            onchange="toggleSelectAll(this.checked)" /></th>
          <th style="cursor:default;user-select:none">
            <div style="display:flex;align-items:center;gap:0.5rem">
              ${bsSelected ? `
              <div class="mode-switch" style="margin-bottom:0" onclick="event.stopPropagation()">
                <button class="${state.filters.namingType !== 'deck' ? 'active' : ''}" onclick="updateFilter('namingType','catalog')">Catalogue</button>
                <button class="${state.filters.namingType === 'deck' ? 'active' : ''}" onclick="updateFilter('namingType','deck')">Deck</button>
              </div>` : ''}
              <span style="cursor:pointer" onclick="toggleSort('name')">Service Name ${state.sort.col==='name' ? (state.sort.dir==='asc'?'▲':'▼') : '⇅'}</span>
            </div>
          </th>
          <th style="cursor:default;user-select:none;width:30%">
            <div style="display:flex;align-items:center;gap:0.5rem">
              <div class="mode-switch" onclick="event.stopPropagation()">
                <button class="${state.filters.etLabelType !== 'service' ? 'active' : ''}" onclick="updateFilter('etLabelType','engagement')">Engagement</button>
                <button class="${state.filters.etLabelType === 'service' ? 'active' : ''}" onclick="updateFilter('etLabelType','service')">Service</button>
              </div>
              <span style="cursor:pointer" onclick="toggleSort('et')">Type ${state.sort.col==='et' ? (state.sort.dir==='asc'?'▲':'▼') : '⇅'}</span>
            </div>
          </th>
          ${showEffort ? `<th style="width:8rem;white-space:nowrap">Typical Effort</th>` : ''}
        </tr>
      </thead>
      <tbody>
        ${(() => {
          let svcs = state.filteredServices.slice(0, 2000);
          if (state.sort.col) {
            const ET_SORT_ORDER = ['Max Success Plan','Advanced Success Plan','Enterprise Support','Embedded Launch Activities','Cloud Prepackaged Services'];
            svcs = [...svcs].sort((a, b) => {
              if (state.sort.col === 'name') {
                const va = a.name||'', vb = b.name||'';
                return state.sort.dir === 'asc' ? va.localeCompare(vb) : vb.localeCompare(va);
              }
              const etsA = Array.isArray(a.engagementType) ? a.engagementType : (a.engagementType ? [a.engagementType] : []);
              const etsB = Array.isArray(b.engagementType) ? b.engagementType : (b.engagementType ? [b.engagementType] : []);
              const rankA = etsA.reduce((min, e) => { const i = ET_SORT_ORDER.indexOf(e); return i >= 0 ? Math.min(min, i) : min; }, 99);
              const rankB = etsB.reduce((min, e) => { const i = ET_SORT_ORDER.indexOf(e); return i >= 0 ? Math.min(min, i) : min; }, 99);
              return state.sort.dir === 'asc' ? rankA - rankB : rankB - rankA;
            });
          }
          return svcs.map(svc => {
          const useDeck = state.filters.namingType === 'deck' && state.filters.businessScenario;
          const bsNaming = svc.business_scenario_naming || svc.businessScenarioNaming || {};
          const bsCode = state.filters.businessScenario;
          const deckNameVal = useDeck ? (bsNaming[bsCode] || null) : null;
          const displayName = deckNameVal || svc.name;
          const subName     = deckNameVal && deckNameVal !== svc.name ? svc.name : null;
          const effortDays = (() => {
            if (!showEffort) return null;
            const cf = svc.classificationFeatures || [];
            const f = cf.find(x => x.key === 'effortEstimateDays');
            if (!f) return null;
            const v = Array.isArray(f.value) ? f.value[0] : f.value;
            return v ? `${v} days` : null;
          })();
          return `
          <tr class="${state.selectedServices.has(svc.code) ? 'selected' : ''}">
            <td><input type="checkbox" ${state.selectedServices.has(svc.code)?'checked':''} onchange="toggleSelect('${svc.code}')" /></td>
            <td>
              <a href="#" onclick="openServiceDetail('${svc.code}');return false"
                style="color:#0070F2;text-decoration:none">${displayName}</a>
              ${subName ? `<div style="font-size:0.75rem;color:#6a6a6a">${subName}</div>` : ''}
            </td>
            <td>${engagementBadge(svc.engagementType)}</td>
            ${showEffort ? `<td style="font-size:0.8rem;color:#556B82">${effortDays || '—'}</td>` : ''}
          </tr>`;
        }).join('');
        })()}
      </tbody>
    </table>` : ''}`;
}

function renderServiceDetailModal() {
  const svc = state.serviceDetail;
  if (!svc) return '';
  const strip = h => (h||'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
  const field = (label, val) => val ? `
    <div style="margin-bottom:0.75rem">
      <div style="font-size:0.72rem;font-weight:600;color:#6a6a6a;text-transform:uppercase;letter-spacing:0.03em;margin-bottom:2px">${label}</div>
      <div style="font-size:0.875rem;color:#1D2D3E">${val}</div>
    </div>` : '';

  const phases = (() => {
    const cf = svc.classificationFeatures || [];
    return cf.filter(f => f.key === 'sapActivateProjectPhase').map(f => f.value).join(', ');
  })();
  const supercats = (() => {
    const cats = svc.supercategories || [];
    return cats.map(c => typeof c === 'string' ? c : c.name || '').filter(Boolean).join(', ');
  })();

  return `
  <div class="modal-overlay" onclick="if(event.target===this)closeServiceDetail()">
    <div class="modal-box" style="max-width:680px">
      <button class="modal-close" onclick="closeServiceDetail()">✕</button>
      <div style="margin-bottom:1rem">
        <h3 style="margin:0 0 0.25rem">${svc.name || ''}</h3>
        ${svc.code ? `<span style="font-size:0.78rem;color:#6a6a6a">${svc.code}</span>` : ''}
        ${svc.serviceNumber ? `<span style="font-size:0.78rem;color:#6a6a6a;margin-left:1rem">#${svc.serviceNumber}</span>` : ''}
        ${svc.url ? `<a href="${svc.url}" target="_blank" rel="noopener" style="font-size:0.78rem;color:#0070F2;margin-left:1rem">↗ SAP Service &amp; Support Catalog</a>` : ''}
      </div>
      ${field('Short Description', strip(svc.shortDescription))}
      ${field('Teaser Text', strip(svc.serviceTeaserText || svc.teaserText))}
      ${field('Summary', strip(svc.summary))}
      ${field('Business Needs', strip(svc.businessNeeds))}
      ${field('Key Benefits', strip(svc.keyBenefits))}
      ${field('Delivery Approach', strip(svc.deliveryApproach))}
      ${field('Description', strip(svc.description))}
      ${field('Phases', phases)}
      ${field('Supercategories', supercats)}
    </div>
  </div>`;
}

function renderIncidentsPage() {
  const { file, results, loading, error } = state.incident;
  return `
    <h2>Incident Analysis</h2>
    <div class="card">
      <h3>Upload Customer Incident File</h3>
      <p style="color:#6a6a6a;font-size:0.875rem">Supported formats: .csv, .xlsx, .txt — max 5 MB</p>
      <div class="upload-area" id="upload-area" ondragover="event.preventDefault(); this.classList.add('dragover')"
           ondragleave="this.classList.remove('dragover')" ondrop="handleDrop(event)">
        <div style="font-size:2rem">📄</div>
        <p>${file ? `<strong>${file.name}</strong> (${(file.size/1024).toFixed(1)} KB)` : 'Drag & drop a file here, or click to browse'}</p>
        <input type="file" id="incident-file" accept=".csv,.xlsx,.txt" style="display:none" onchange="handleFileSelect(event)" />
        <button class="btn btn-secondary btn-sm" onclick="document.getElementById('incident-file').click()">Browse</button>
      </div>
      ${error ? `<div class="error-strip" style="margin-top:1rem">⚠ ${error}</div>` : ''}
      ${file ? `<button class="btn btn-primary" style="margin-top:1rem" onclick="analyzeIncidents()" ${loading?'disabled':''}>
        ${loading ? '⏳ Analyzing...' : '🔍 Analyze Incidents'}
      </button>` : ''}
    </div>
    ${loading ? '<div class="loading"><div class="loading-spinner"></div> Analyzing incidents with AI agent...</div>' : ''}
    ${results.length > 0 ? `
    <div class="card">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem">
        <h3 style="margin:0">${results.length} Recommended Services</h3>
        <button class="btn btn-primary btn-sm" onclick="addIncidentResultsToCart()">
          Add Selected to Export Cart (${state.incident.selectedCodes.size})
        </button>
      </div>
      ${results.map(svc => `
        <div class="incident-result">
          <input type="checkbox" ${state.incident.selectedCodes.has(svc.code)?'checked':''} onchange="toggleIncidentSelect('${svc.code}')" />
          <div style="flex:1">
            <div style="font-weight:600">${svc.name}</div>
            <div style="font-size:0.8rem;color:#6a6a6a;margin-top:2px">${svc.shortDescription}</div>
            ${svc.relevance_rationale ? `<div style="font-size:0.8rem;color:#0070F2;margin-top:4px;font-style:italic">💡 ${svc.relevance_rationale}</div>` : ''}
            ${engagementBadge(svc.engagementType)}
          </div>
        </div>`).join('')}
    </div>` : ''}`;
}

function renderExportPage() {
  const cartServices = state.exportCart.map(code => {
    const svc = state.catalog.services.find(s => s.code === code);
    return svc || { code, name: code, shortDescription: 'Service details not loaded' };
  });

  return `
    <h2>PPTX Export</h2>
    ${state.pptx.error ? `<div class="error-strip">⚠ ${state.pptx.error}</div>` : ''}
    <div class="card">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem">
        <h3 style="margin:0">Export Cart (${cartServices.length} services)</h3>
        <button class="btn btn-danger btn-sm" onclick="clearCart()">🗑 Clear Cart</button>
      </div>
      ${cartServices.length > 50 ? `<div class="error-strip">⚠ Maximum 50 services per export. Please remove ${cartServices.length - 50} service(s).</div>` : ''}
      ${cartServices.length === 0 ? `
        <div class="empty-state">
          <p>Your export cart is empty. Go to the <a href="#" onclick="navigate('catalog')">Catalogue Browser</a> or
          <a href="#" onclick="navigate('incidents')">Incident Analysis</a> to add services.</p>
        </div>` : `
      <table class="service-table">
        <thead><tr><th>Service Name</th><th>Short Description</th><th>Code</th><th></th></tr></thead>
        <tbody>
          ${cartServices.map(svc => `
            <tr>
              <td><strong>${svc.name}</strong></td>
              <td style="font-size:0.8rem">${(svc.shortDescription||'').substring(0,100)}</td>
              <td style="font-size:0.75rem;color:#6a6a6a">${svc.code}</td>
              <td><button class="btn btn-danger btn-sm" onclick="removeFromCart('${svc.code}')">✕</button></td>
            </tr>`).join('')}
        </tbody>
      </table>`}
    </div>
    <div class="card">
      <h3>Choose Template</h3>
      <div class="template-option ${state.pptx.template==='short-description'?'selected':''}" onclick="selectTemplate('short-description')">
        <input type="radio" name="template" value="short-description" ${state.pptx.template==='short-description'?'checked':''} />
        <div>
          <label style="font-weight:600">📋 Short Description List</label>
          <div style="font-size:0.8rem;color:#6a6a6a;margin-top:2px">One summary slide with all selected services — names, short descriptions, engagement types, and modules in a table.</div>
        </div>
      </div>
      <div class="template-option ${state.pptx.template==='one-pager'?'selected':''}" onclick="selectTemplate('one-pager')">
        <input type="radio" name="template" value="one-pager" ${state.pptx.template==='one-pager'?'checked':''} />
        <div>
          <label style="font-weight:600">📄 One-Pager per Service</label>
          <div style="font-size:0.8rem;color:#6a6a6a;margin-top:2px">One dedicated slide per service with full details — name, description, engagement type, module, and business scenarios.</div>
        </div>
      </div>
      <button class="btn btn-primary" style="margin-top:1rem" onclick="generatePptx()"
        ${state.pptx.generating || cartServices.length === 0 || cartServices.length > 50 ? 'disabled' : ''}>
        ${state.pptx.generating ? '⏳ Generating...' : '⬇ Generate & Download PowerPoint'}
      </button>
    </div>`;
}

function renderChatPage() {
  const { messages, loading, input } = state.chat;
  return `
    <h2>Agent Chat</h2>
    <div class="card" style="padding:0">
      <div class="chat-messages" id="chat-messages">
        ${messages.length === 0 ? `<div style="text-align:center;color:#6a6a6a;margin:auto">
          <p>💬 Ask me anything about the SSC Services Catalog.</p>
          <p style="font-size:0.8rem">Examples:<br>
          "Which services are in Max Success Plan for SAP IBP?"<br>
          "Show me all data migration services"<br>
          "What services help with performance optimization?"</p>
        </div>` : ''}
        ${messages.map(m => `<div class="chat-msg ${m.role}">${m.content}</div>`).join('')}
        ${loading ? '<div class="loading"><div class="loading-spinner"></div> Agent is thinking...</div>' : ''}
      </div>
      <div class="chat-input-row" style="padding:0.75rem;border-top:1px solid #e0e0e0">
        <input type="text" id="chat-input" value="${input}" placeholder="Ask a question..."
          onkeydown="if(event.key==='Enter')sendMessage()" oninput="state.chat.input=this.value" />
        <label style="cursor:pointer" title="Attach incident file">
          📎
          <input type="file" accept=".csv,.xlsx,.txt" style="display:none" onchange="attachFileToChat(event)" />
        </label>
        <button class="btn btn-primary" onclick="sendMessage()" ${loading?'disabled':''}>Send</button>
      </div>
    </div>`;
}

// ── Event handlers ─────────────────────────────────────────────────────────────

window.navigate = function(page) {
  const p = state.myPermissions;
  const allowed = { catalog: p.catalog, incidents: p.incidents, chat: p.chat, debug: p.debug, exportlog: p.exportlog, admin: p.admin };
  if (!allowed[page]) {
    state.accessDeniedModal = true;
    render();
    return;
  }
  state.currentPage = page;
  render();
  if (page === 'catalog' && !state.catalog.bsMap) loadCatalog();
  if (page === 'debug') loadDebugLog();
  if (page === 'exportlog') loadExportLog();
  if (page === 'admin') { loadAdminUsers(); loadAdminVisitorLog(); loadAdminMcpRequests(); }
  // Log page visit
  apiFetch(`${CAP_BACKEND_URL}/api/catalog/visitor`, { method: 'POST', body: JSON.stringify({ page, sessionId: state.sessionId }) }).catch(() => {});
};


window.updateFilter = function(key, value) {
  state.filters[key] = value;
  if (key === 'businessScenario') { state.filters.modules = []; state.filters.module = ''; state.filters.deckName = ''; state.filters.namingType = ''; }
  // These keys change filter panel structure — full re-render
  const needsFullRender = key === 'businessScenario' || key === 'engagementType';
  // Icon/mode switches — update button active classes in-place, no panel re-render
  const isModeSwitch = key === 'phaseMode' || key === 'advancedLoSMode' || key === 'foundationalCatsMode' || key === 'maxFocusTopicsMode';
  clearTimeout(window._filterDebounce);
  if (needsFullRender) {
    patchFilters();
    window._filterDebounce = setTimeout(applyFilters, 300);
  } else if (isModeSwitch) {
    // Surgically update only the two buttons of the affected icon-switch
    const switchMap = { phaseMode: 'phaseMode', advancedLoSMode: 'advancedLoSMode', foundationalCatsMode: 'foundationalCatsMode', maxFocusTopicsMode: 'maxFocusTopicsMode' };
    document.querySelectorAll(`.icon-switch`).forEach(sw => {
      const [btnA, btnB] = sw.querySelectorAll('button');
      if (!btnA || !btnB) return;
      const onMerge  = btnA.getAttribute('onclick') || '';
      const onIntersect = btnB.getAttribute('onclick') || '';
      if (onMerge.includes(key)) {
        btnA.classList.toggle('active', value === 'merge');
        btnB.classList.toggle('active', value === 'intersect');
      }
    });
    window._filterDebounce = setTimeout(applyFilters, 300);
  } else if (key === 'namingType' || key === 'etLabelType') {
    patchResults();
  } else {
    window._filterDebounce = setTimeout(applyFilters, 300);
  }
};

const MODE_KEYS = { phases: 'phaseMode', advancedLoS: 'advancedLoSMode', foundationalCats: 'foundationalCatsMode' };
window.updateCheckboxFilter = function(key, value, checked) {
  const arr = state.filters[key] ? [...state.filters[key]] : [];
  if (checked && !arr.includes(value)) arr.push(value);
  else if (!checked) { const i = arr.indexOf(value); if (i > -1) arr.splice(i, 1); }
  state.filters[key] = arr;
  if (MODE_KEYS[key] && arr.length < 2) state.filters[MODE_KEYS[key]] = 'merge';
  patchFilters();
  clearTimeout(window._filterDebounce);
  window._filterDebounce = setTimeout(applyFilters, 300);
};
window.updateCheckboxFilter._clearKey = function(key) {
  state.filters[key] = [];
  if (key === 'modules') state.filters.module = '';
  if (MODE_KEYS[key]) state.filters[MODE_KEYS[key]] = 'merge';
  patchFilters();
  clearTimeout(window._filterDebounce);
  window._filterDebounce = setTimeout(applyFilters, 300);
};

window.updateMultiFilter = function(key, selectEl) {
  const selected = Array.from(selectEl.selectedOptions).map(o => o.value);
  state.filters[key] = selected;
  if (key === 'modules') state.filters.module = selected.length === 1 ? selected[0] : '';
  clearTimeout(window._filterDebounce);
  window._filterDebounce = setTimeout(applyFilters, 300);
};

window.updateMultiFilterUI5 = function(key, combobox) {
  const selected = Array.from(combobox.querySelectorAll('ui5-mcb-item[selected]')).map(i => i.dataset.value || i.getAttribute('text'));
  state.filters[key] = selected;
  if (key === 'modules') state.filters.module = selected.length === 1 ? selected[0] : '';
  clearTimeout(window._filterDebounce);
  window._filterDebounce = setTimeout(applyFilters, 300);
};

window.toggleMoreFilters = function() {
  state.filtersExpanded = !state.filtersExpanded;
  patchFilters();
};

window.clearFilters = function() {
  state.filters = { query: '', engagementType: '', businessScenario: '', module: '', modules: [], phases: [], phaseMode: 'merge', supercats: [], advancedLoS: [], advancedLoSMode: 'merge', foundationalCats: [], foundationalCatsMode: 'merge', maxFocusTopics: [], maxFocusTopicsMode: 'merge', deckName: '', namingType: '', etLabelType: 'engagement' };
  state.filteredServices = [];
  state.catalog.hasSearched = false;
  render();
};

window.toggleSelect = function(code) {
  if (state.selectedServices.has(code)) state.selectedServices.delete(code);
  else state.selectedServices.add(code);
  patchResults();
};

window.addSelectedToCart = function() {
  state.selectedServices.forEach(code => {
    if (!state.exportCart.includes(code)) state.exportCart.push(code);
  });
  state.selectedServices.clear();
  saveCart();
  render();
  alert(`Added to export cart! Cart now has ${state.exportCart.length} service(s).`);
};

window.removeFromCart = function(code) {
  state.exportCart = state.exportCart.filter(c => c !== code);
  saveCart(); render();
};

window.clearCart = function() {
  state.exportCart = []; saveCart(); state.pptx.downloadUrl = null; render();
};

window.handleFileSelect = function(event) {
  const file = event.target.files[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) { alert('File too large (max 5 MB)'); return; }
  state.incident.file = file;
  state.incident.results = []; state.incident.error = null;
  render();
};

window.handleDrop = function(event) {
  event.preventDefault();
  document.getElementById('upload-area')?.classList.remove('dragover');
  const file = event.dataTransfer.files[0];
  if (file) { const dt = new DataTransfer(); dt.items.add(file); document.getElementById('incident-file').files = dt.files; window.handleFileSelect({ target: { files: [file] }}); }
};

window.analyzeIncidents = async function() {
  if (!state.incident.file) return;
  state.incident.loading = true; state.incident.error = null; render();
  try {
    const text = await state.incident.file.text();
    const body = JSON.stringify({
      message: `Analyze these customer incidents and recommend relevant SSC catalog services. Here is the file content:\n\n${text.substring(0, 50000)}`,
      contextId: 'incident-analysis-' + Date.now()
    });
    const res = await fetch(`${CAP_BACKEND_URL}/api/agent/chat`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: `Analyze these customer incidents and recommend relevant SSC catalog services. Here is the file content:\n\n${text.substring(0, 50000)}`, contextId: 'incident-analysis-' + Date.now() }) });
    if (!res.ok) throw new Error(`Agent API error ${res.status}`);
    const data = await res.json();
    const content = data.message || data.content || JSON.stringify(data);
    // Parse service codes from agent response text
    state.incident.results = (state.catalog.services || [])
      .filter(s => content.toLowerCase().includes(s.name.toLowerCase().substring(0, 20)))
      .slice(0, 15)
      .map(s => ({ ...s, relevance_rationale: 'Matched based on incident content analysis' }));
    if (state.incident.results.length === 0) {
      state.incident.results = [{ code: 'info', name: 'Agent response', shortDescription: content.substring(0, 300), relevance_rationale: '' }];
    }
  } catch (e) { state.incident.error = e.message; }
  state.incident.loading = false; render();
};

window.toggleIncidentSelect = function(code) {
  if (state.incident.selectedCodes.has(code)) state.incident.selectedCodes.delete(code);
  else state.incident.selectedCodes.add(code);
  render();
};

window.addIncidentResultsToCart = function() {
  state.incident.selectedCodes.forEach(code => {
    if (!state.exportCart.includes(code)) state.exportCart.push(code);
  });
  state.incident.selectedCodes.clear();
  saveCart();
  alert(`Added to export cart! Cart now has ${state.exportCart.length} service(s).`);
  render();
};

window.toggleSelectAll = function(checked) {
  if (checked) state.filteredServices.forEach(s => state.selectedServices.add(s.code));
  else state.selectedServices.clear();
  patchResults();
};

window.toggleSort = function(col) {
  if (state.sort.col === col) state.sort.dir = state.sort.dir === 'asc' ? 'desc' : 'asc';
  else { state.sort.col = col; state.sort.dir = 'asc'; }
  patchResults();
};

window.generatePptx = async function(template) {
  // Flush year inputs immediately in case debounce hasn't fired yet
  const yfEl = document.getElementById('pptx-year-from');
  const ytEl = document.getElementById('pptx-year-to');
  if (yfEl) state.pptxListSettings.yearFrom = yfEl.value.replace(/\D/g,'').slice(0,4);
  if (ytEl) state.pptxListSettings.yearTo   = ytEl.value.replace(/\D/g,'').slice(0,4);
  const codes = state.selectedServices.size > 0
    ? [...state.selectedServices]
    : state.filteredServices.map(s => s.code);
  if (codes.length === 0) { alert('No services to export.'); return; }
  const isListTemplate = template === 'list';
  if (!isListTemplate && codes.length > 50) { alert(`Too many services (${codes.length}). Max 50 for PPTX. Please select fewer.`); return; }
  state.pptx.generating = true; state.pptx.error = null; state.pptx.downloadUrl = null; render();
  try {
    const body = {
      serviceCodes: codes,
      template: template || 'short-description',
      filterEt:    state.filters.engagementType || null,
      filterQuery: state.filters.query          || null,
    };
    if (isListTemplate) {
      const s = state.pptxListSettings;
      const bsCode = state.filters.businessScenario || null;
      const mods = state.filters.modules || [];
      // Resolve stream label for PPTX
      let resolvedStreamMode = s.streamMode;
      let resolvedStreamCustom = s.streamCustom;
      if (!bsCode && resolvedStreamMode !== 'customNoBS') {
        resolvedStreamMode = 'moduleOnly';
      }
      // Build selectedModuleCodes: explicit selection, or all BS modules when BS selected + none checked
      const selectedModuleCodes = (() => {
        if (mods.length > 1) return mods;
        if (mods.length === 1) return mods;
        if (mods.length === 0 && state.filters.module) return [state.filters.module];
        if (mods.length === 0 && bsCode) return (state.catalog.bsToMods || {})[bsCode] || null;
        return null;
      })();
      body.listOptions = {
        cols: { ...s.cols, stream: bsCode ? s.cols.stream : false },
        yearFrom: s.years ? s.yearFrom : '0',
        yearTo:   s.years ? s.yearTo   : '0',
        groupByET: s.groupByET,
        groupMode: (!bsCode || resolvedStreamMode === 'custom') ? 'acrossAll' : 'perModule',
        useDeckName: s.useDeckName,
        yearBorders: s.years ? s.yearBorders : false,
        title: s.title,
        bsCode,
        streamMode: resolvedStreamMode,
        streamCustom: resolvedStreamCustom,
        truncateObjectives: s.truncateObjectives,
        switchTypes: s.switchTypes,
        moduleName: (() => {
          if (mods.length === 1) return state.catalog.moduleMap[mods[0]] || mods[0];
          if (mods.length === 0 && state.filters.module) return state.catalog.moduleMap[state.filters.module] || state.filters.module;
          return null;
        })(),
        selectedModuleCodes,
      };
    }
    const data = await apiFetch(`${CAP_BACKEND_URL}/api/pptx/generatePptx`, {
      method: 'POST',
      body: JSON.stringify(body)
    });
    state.pptx.downloadUrl = data.downloadUrl;
    if (state.exportTotal != null) state.exportTotal++;
    const a = document.createElement('a');
    a.href = `${CAP_BACKEND_URL}${data.downloadUrl}`;
    a.download = data.filename;
    a.click();
  } catch (e) { state.pptx.error = e.message; }
  state.pptx.generating = false; render();
};

window.openServiceDetail = function(code) {
  state.serviceDetail = state.filteredServices.find(s => s.code === code) || null;
  render();
};
window.closeServiceDetail = function() {
  state.serviceDetail = null; render();
};

window.openPptxListSettings = function() {
  state.pptxListSettings.open = true; render();
};
window.openExcelSettings = function() {
  state.excelSettings.open = true; render();
};
window.closeExcelSettings = function() {
  state.excelSettings.open = false; render();
};
window.toggleExcelPdMode = function() {
  state.excelSettings.pdMode = !state.excelSettings.pdMode; render();
};
window.setExcelYear = function(field, val) {
  state.excelSettings[field] = val.replace(/\D/g,'').slice(0,4); render();
};
window.closePptxListSettings = function() {
  state.pptxListSettings.open = false; render();
};
window.togglePptxCol = function(col) {
  state.pptxListSettings.cols[col] = !state.pptxListSettings.cols[col]; render();
};
window.setPptxYears = function(checked) {
  state.pptxListSettings.years = checked; render();
};
let _yearDebounce = null;
window.setPptxYearFrom = function(v) {
  state.pptxListSettings.yearFrom = v.replace(/\D/g,'').slice(0,4);
  clearTimeout(_yearDebounce); _yearDebounce = setTimeout(render, 1000);
};
window.setPptxYearTo = function(v) {
  state.pptxListSettings.yearTo = v.replace(/\D/g,'').slice(0,4);
  clearTimeout(_yearDebounce); _yearDebounce = setTimeout(render, 1000);
};
window.setPptxGroupET = function(v) {
  state.pptxListSettings.groupByET = v; render();
};
window.setPptxDeckName = function(v) {
  state.pptxListSettings.useDeckName = v; render();
};
window.setPptxYearBorders = function(v) {
  state.pptxListSettings.yearBorders = v; render();
};
let _titleDebounce = null;
window.setPptxTitle = function(v) {
  state.pptxListSettings.title = v;
  clearTimeout(_titleDebounce); _titleDebounce = setTimeout(render, 1000);
};
window.setPptxStreamMode = function(v) {
  state.pptxListSettings.streamMode = v; render();
};
window.setPptxStreamCustom = function(v) {
  state.pptxListSettings.streamCustom = v.slice(0, 64);
  // No render() — value= attr keeps input in sync, re-render would reset cursor
};
window.setPptxTruncateObjectives = function(v) {
  state.pptxListSettings.truncateObjectives = v; render();
};
window.setPptxSwitchTypes = function(v) {
  state.pptxListSettings.switchTypes = v; render();
};

function renderPptxListSettingsModal() {
  const s = state.pptxListSettings;
  if (!s.open) return '';
  const bsActive = !!state.filters.businessScenario;
  const yf = parseInt(s.yearFrom,10)||0, yt = parseInt(s.yearTo,10)||0;
  const yearValid = !s.years || (s.yearFrom.length===4 && s.yearTo.length===4 && yf>=2000 && yf<=2050 && yt>=2000 && yt<=2033 && yf<yt);

  const activeET = state.filters.engagementType || '';
  const truncateEnabled = !activeET || activeET.toLowerCase().includes('foundational') || activeET.toLowerCase().includes('enterprise support');
  const pdEnabled = !activeET || activeET.toLowerCase().includes('max');

  const streamOn = s.cols.stream && bsActive;

  const sectionLabel = 'font-weight:600;font-size:0.82rem;color:#1D2D3E;margin-bottom:0.5rem;margin-top:0.85rem';
  const checkLabel   = 'display:flex;align-items:center;gap:0.5rem;cursor:pointer;font-size:0.875rem';
  const checkLabelOff = 'display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;opacity:0.45;cursor:not-allowed;color:#9BA8B0;';
  const tip = (text) => `<span title="${text}" style="display:inline-flex;align-items:center;justify-content:center;width:0.82rem;height:0.82rem;border-radius:50%;background:#1D6FA4;color:#fff;font-size:0.6rem;font-weight:700;cursor:default;flex-shrink:0;line-height:1">?</span>`;

  const streamOptions = bsActive ? `
    <div style="display:flex;flex-direction:column;gap:0.35rem">
      <label style="display:flex;align-items:center;gap:0.5rem;cursor:pointer;font-size:0.875rem">
        <input type="radio" name="streamMode" value="bsAndModule" ${s.streamMode==='bsAndModule'?'checked':''} onchange="setPptxStreamMode('bsAndModule')"/>
        Business Scenario + Module Name ${tip('Combines scenario and module into one stream label for full context')}
      </label>
      <label style="display:flex;align-items:center;gap:0.5rem;cursor:pointer;font-size:0.875rem">
        <input type="radio" name="streamMode" value="moduleOnly" ${s.streamMode==='moduleOnly'?'checked':''} onchange="setPptxStreamMode('moduleOnly')"/>
        Only Module Name ${tip('Label shows just the module name, stripping the Business Scenario prefix')}
      </label>
      <label style="display:flex;align-items:center;gap:0.5rem;cursor:pointer;font-size:0.875rem">
        <input type="radio" name="streamMode" value="custom" ${s.streamMode==='custom'?'checked':''} onchange="setPptxStreamMode('custom')"/>
        Custom ${tip('Use your own fixed text as the stream label on every slide')}
      </label>
      ${s.streamMode==='custom' ? `
      <input type="text" id="pptx-stream-custom" maxlength="64" oninput="setPptxStreamCustom(this.value)"
        value="${s.streamCustom.replace(/"/g,'&quot;')}"
        style="margin-left:1.5rem;width:calc(100% - 1.5rem);padding:0.35rem 0.5rem;font-size:0.875rem;border:1px solid #8696A9;border-radius:4px"
        placeholder="Custom stream label (max 64 chars)"/>` : ''}
    </div>` : '';

  return `
  <div class="modal-overlay" onclick="if(event.target===this)closePptxListSettings()">
    <div class="modal-box" style="max-width:750px">
      <button class="modal-close" onclick="closePptxListSettings()">✕</button>
      <h3 style="margin-top:0">⚙ PPTX List — Export Settings</h3>

      <div style="font-size:0.82rem;color:#6a6a6a;margin-bottom:1rem">
        Set up slides header, choose columns to include, and configure formatting options. Changes apply to this export.
      </div>

      <!-- Slide Title -->
      <div style="${sectionLabel}">Service Title ${tip('Override the slide header text shown at the top of each generated slide')}</div>
      <input type="text" id="pptx-slide-title" value="${s.title.replace(/"/g,'&quot;')}" oninput="setPptxTitle(this.value)"
        style="width:100%;margin-bottom:0.5rem" placeholder="Services Description"/>

      <!-- Columns — 4 in one row -->
      <div style="${sectionLabel}">Columns ${tip('Select which columns appear in the output table')}</div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:0.4rem 1rem;margin-bottom:0.75rem">
        ${colCheck('phases',     'Activate Phases',  s.cols.phases,     false)}
        ${colCheck('component',  'Service Name',     s.cols.component,  false)}
        ${colCheck('tier',       'Type',             s.cols.tier,       false)}
        ${colCheck('objectives', 'Short Description', s.cols.objectives, false)}
      </div>

      <!-- Stream | Timeline row 50/50 -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-bottom:0.75rem">
        <!-- Stream — hidden when no BS -->
        <div style="${bsActive ? '' : 'display:none'}">
          <label style="${streamOn ? checkLabel : checkLabelOff}" ${!bsActive?'title="Only available when Business Scenario is selected"':''}>
            <input type="checkbox" ${streamOn?'checked':''} ${!bsActive?'disabled':''} onchange="togglePptxCol('stream')"/>
            Stream ${tip('Shows a side label per slide indicating the module or scenario grouping')}
          </label>
          <div style="margin-top:0.4rem;padding:0.6rem 0.75rem;background:#f7f8f9;border-radius:6px;border:1px solid #e0e0e0;${streamOn?'':'display:none'}">
            ${streamOptions}
          </div>
        </div>
        <!-- Timeline (Years) -->
        <div>
          <label style="${checkLabel}">
            <input type="checkbox" ${s.years?'checked':''} onchange="setPptxYears(this.checked)"/>
            Timeline (Years) ${tip('Inserts year columns so services can be mapped to a delivery timeline')}
          </label>
          <div style="margin-top:0.4rem;padding:0.6rem 0.75rem;background:#f7f8f9;border-radius:6px;border:1px solid #e0e0e0;${s.years?'':'opacity:0.45;pointer-events:none;'}">
            <div style="display:flex;gap:0.75rem;align-items:flex-end;margin-bottom:0.6rem">
              <div>
                <div style="font-size:0.72rem;color:#6a6a6a;margin-bottom:3px">Year From</div>
                <input type="text" id="pptx-year-from" maxlength="4" oninput="setPptxYearFrom(this.value)"
                  style="width:80px;padding:0.4rem 0.5rem;font-size:0.875rem;border:1px solid ${!yearValid&&s.yearFrom.length===4?'#dc3545':'#8696A9'};border-radius:4px;text-align:center"
                  placeholder="2026"/>
              </div>
              <div style="padding-bottom:0.5rem;color:#6a6a6a">→</div>
              <div>
                <div style="font-size:0.72rem;color:#6a6a6a;margin-bottom:3px">Year To</div>
                <input type="text" id="pptx-year-to" maxlength="4" oninput="setPptxYearTo(this.value)"
                  style="width:80px;padding:0.4rem 0.5rem;font-size:0.875rem;border:1px solid ${!yearValid&&s.yearTo.length===4?'#dc3545':'#8696A9'};border-radius:4px;text-align:center"
                  placeholder="2030"/>
              </div>
              ${!yearValid ? `<div style="font-size:0.72rem;color:#dc3545;align-self:flex-end;padding-bottom:0.5rem">Year From &lt; Year To, and Year To ≤ 2033</div>` : ''}
            </div>
            <label style="${checkLabel}">
              <input type="checkbox" ${s.yearBorders?'checked':''} onchange="setPptxYearBorders(this.checked)"/>
              Show year column borders
            </label>
          </div>
        </div>
      </div>

      <!-- Options -->
      <div style="${sectionLabel}">Options</div>
      <div style="display:flex;flex-direction:column;gap:0.4rem;margin-bottom:1.25rem">
        <label style="${!activeET?checkLabel:checkLabelOff}" ${activeET?'title="Not available when Engagement Type filter is active"':''}>
          <input type="checkbox" ${s.groupByET?'checked':''} ${activeET?'disabled':''} onchange="setPptxGroupET(this.checked)"/>
          Grouping rows by Engagement Type ${tip(bsActive && s.streamMode !== 'custom' ? 'Sorts rows within each module by tier: Max first, then Advanced, then Foundational' : 'Sorts all rows by tier across the full list: Max first, then Advanced, then Foundational')}
        </label>
        <label style="${bsActive?checkLabel:checkLabelOff}" ${!bsActive?'title="Only available when Business Scenario is selected"':''}>
          <input type="checkbox" ${s.useDeckName?'checked':''} ${!bsActive?'disabled':''} onchange="setPptxDeckName(this.checked)"/>
          Use Deck Names in Service Name column ${tip('Replaces technical service names with the presentation deck label for this scenario')}
        </label>
        <label style="${truncateEnabled?checkLabel:checkLabelOff}" ${truncateEnabled?'':'title="Only applies when ET is unset or Foundational"'}>
          <input type="checkbox" ${s.truncateObjectives?'checked':''} ${truncateEnabled?'':'disabled'} onchange="setPptxTruncateObjectives(this.checked)"/>
          Truncate EGIs description to 3 sentences ${tip('Limits EGI service descriptions to 3 sentences — reduces row height on dense slides')}
        </label>
        <label style="${checkLabel}">
          <input type="checkbox" ${s.switchTypes?'checked':''} onchange="setPptxSwitchTypes(this.checked)"/>
          Switch Types to Premium / Entitlements ${tip('Replaces engagement type labels with service types: Max → Premium Service, others → Service Entitlement')}
        </label>
        <label style="${pdEnabled?checkLabel:checkLabelOff}" ${!pdEnabled?'title="Not available when Engagement Type is Advanced or Foundational"':''}>
          <input type="checkbox" ${s.cols.pd?'checked':''} ${!pdEnabled?'disabled':''} onchange="togglePptxCol('pd')"/>
          Show typical effort estimates (if any) in PD column ${tip('Adds a narrow PD column after the objectives with effort estimate numbers for Max services')}
        </label>
      </div>

      <div style="display:flex;gap:0.75rem;justify-content:flex-end">
        <button class="btn btn-secondary btn-sm" onclick="closePptxListSettings()">Cancel</button>
        <button class="btn btn-primary btn-sm" onclick="generatePptx('list').then(()=>closePptxListSettings())"
          ${!yearValid ? 'disabled title="Fix year range first"' : ''}>
          ⬇ Export Now
        </button>
      </div>
    </div>
  </div>`;
}

function colCheck(key, label, checked, disabled, title) {
  const dis = disabled ? 'disabled' : '';
  const op  = disabled ? 'opacity:0.45;color:#9BA8B0;' : '';
  const tt  = title ? `title="${title}"` : '';
  return `<label style="display:flex;align-items:center;gap:0.5rem;cursor:${disabled?'not-allowed':'pointer'};font-size:0.875rem;${op}" ${tt}>
    <input type="checkbox" ${checked?'checked':''} ${dis} onchange="togglePptxCol('${key}')"/> ${label}
  </label>`;
}

window.exportExcel = async function() {
  const s = state.excelSettings;
  const svcs = state.selectedServices.size > 0
    ? state.filteredServices.filter(x => state.selectedServices.has(x.code))
    : state.filteredServices;
  if (svcs.length === 0) { alert('No services to export.'); return; }
  state.excelSettings.open = false; render();
  try {
    const bsCode = state.filters.businessScenario || null;
    const bsName = bsCode ? ((state.catalog.bsMap || {})[bsCode] || bsCode) : null;
    const res = await apiFetch(`${CAP_BACKEND_URL}/api/catalog/export-excel`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        services: svcs,
        pdMode: s.pdMode,
        yearFrom: s.pdMode ? s.yearFrom : null,
        yearTo:   s.pdMode ? s.yearTo   : null,
        bsCode,
        bsName,
      })
    });
    const a = document.createElement('a'); a.href = res.downloadUrl;
    a.download = `ssc_export_${new Date().toISOString().slice(0,10)}.xlsx`;
    a.click();
  } catch(e) { alert('Export failed: ' + e.message); }
};

function renderExcelSettingsModal() {
  const s = state.excelSettings;
  if (!s.open) return '';
  const yf = parseInt(s.yearFrom,10)||0, yt = parseInt(s.yearTo,10)||0;
  const yearValid = !s.pdMode || (s.yearFrom.length===4 && s.yearTo.length===4 && yf>=2000 && yf<=2050 && yt>=yf);
  const inp = 'width:70px;padding:0.3rem 0.4rem;font-size:0.875rem;border:1px solid #8696A9;border-radius:4px;text-align:center';
  return `
  <div class="modal-overlay" onclick="if(event.target===this)closeExcelSettings()">
    <div class="modal-box" style="max-width:480px">
      <button class="modal-close" onclick="closeExcelSettings()">✕</button>
      <h3 style="margin-top:0;display:flex;align-items:center;gap:8px">
        <img src="excel.svg" style="height:18px;width:auto" alt=""/>Excel Export Settings
      </h3>
      <div style="font-size:0.82rem;color:#6a6a6a;margin-bottom:1.25rem">
        Configure the export format before downloading.
      </div>
      <label style="display:flex;align-items:flex-start;gap:0.6rem;cursor:pointer;font-size:0.875rem;margin-bottom:1rem">
        <input type="checkbox" ${s.pdMode?'checked':''} onclick="toggleExcelPdMode()" style="margin-top:2px"/>
        <span><strong>Export option for premium days calculation</strong><br/>
        <span style="font-size:0.78rem;color:#6a6a6a">Exports CRM ID, link, Name, PD and year columns formatted as an Excel table with totals row</span></span>
      </label>
      <div style="${s.pdMode?'':'opacity:0.45;pointer-events:none'}">
        <div style="font-weight:600;font-size:0.82rem;margin-bottom:0.5rem">Year range</div>
        <div style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem">
          <input type="text" maxlength="4" value="${s.yearFrom}" oninput="setExcelYear('yearFrom',this.value)" style="${inp}" placeholder="2026" ${s.pdMode?'':'disabled'}/>
          <span>—</span>
          <input type="text" maxlength="4" value="${s.yearTo}" oninput="setExcelYear('yearTo',this.value)" style="${inp}" placeholder="2030" ${s.pdMode?'':'disabled'}/>
          ${!yearValid && s.pdMode ? `<span style="color:#c00;font-size:0.78rem">Invalid range</span>` : ''}
        </div>
      </div>
      <div style="display:flex;justify-content:flex-end;gap:0.75rem;margin-top:1.5rem">
        <button class="btn btn-secondary btn-sm" onclick="closeExcelSettings()">Cancel</button>
        <button class="btn btn-primary btn-sm" onclick="exportExcel()" ${!yearValid?'disabled':''}>⬇ Export Now</button>
      </div>
    </div>
  </div>`;
}

window.sendMessage = async function() {
  const input = document.getElementById('chat-input')?.value || state.chat.input;
  if (!input.trim()) return;
  state.chat.messages.push({ role: 'user', content: input });
  state.chat.input = ''; state.chat.loading = true; render();
  scrollChatToBottom();
  try {
    const res = await fetch(`${CAP_BACKEND_URL}/api/agent/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: input, contextId: 'chat-session' })
    });
    if (!res.ok) throw new Error(`Agent error ${res.status}`);
    const data = await res.json();
    state.chat.messages.push({ role: 'agent', content: data.message || data.content || 'No response received.' });
  } catch (e) {
    state.chat.messages.push({ role: 'agent', content: `Error: ${e.message}` });
  }
  state.chat.loading = false; render(); scrollChatToBottom();
};

window.attachFileToChat = function(event) {
  const file = event.target.files[0];
  if (!file) return;
  state.incident.file = file;
  navigate('incidents');
};

function scrollChatToBottom() {
  setTimeout(() => {
    const el = document.getElementById('chat-messages');
    if (el) el.scrollTop = el.scrollHeight;
  }, 50);
}

// ── Debug / Matching Log ───────────────────────────────────────────────────────

async function loadDebugLog() {
  state.debug.loading = true;
  state.debug.error = null;
  try {
    const params = new URLSearchParams();
    if (state.debug.bsCode)       params.set('bsCode',      state.debug.bsCode);
    if (state.debug.module)       params.set('module',      state.debug.module);
    if (state.debug.serviceName)  params.set('serviceName', state.debug.serviceName);
    if (state.debug.status)       params.set('status',      state.debug.status);
    const res = await fetch(`${CAP_BACKEND_URL}/api/catalog/injection-log?${params}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    state.debug.rows   = data.rows   || [];
    state.debug.totals = data.totals || null;
  } catch (e) {
    state.debug.error = e.message;
    state.debug.rows  = [];
  }
  state.debug.loading = false;
  render();
}

let _debugFilterTimer = null;

window.updateDebugFilter = function(key, value, debounce) {
  state.debug[key] = value;
  if (debounce) {
    clearTimeout(_debugFilterTimer);
    _debugFilterTimer = setTimeout(() => loadDebugLog(), 500);
  } else {
    loadDebugLog();
  }
};

function renderDebugPage() {
  const { bsCode, module, serviceName, status, rows, totals, loading, error } = state.debug;

  const bsOptions = Object.entries(state.catalog.bsMap || {})
    .map(([code, name]) => {
      const label = name.includes('-') ? name.replace(/^[^-]+-\s*/, '') : name;
      return `<option value="${code}" ${bsCode === code ? 'selected' : ''}>${label}</option>`;
    })
    .sort((a, b) => a.localeCompare(b))
    .join('');

  const statusOptions = [
    ['',                  'All statuses'],
    ['Added',             'Added'],
    ['Already Linked',    'Already Linked'],
    ['No Module Match',   'No Module Match'],
    ['No Service Match',  'No Service Match'],
  ].map(([v, l]) => `<option value="${v}" ${status === v ? 'selected' : ''}>${l}</option>`).join('');

  const totalsHtml = totals ? `
    <div style="display:flex;gap:1.5rem;flex-wrap:wrap;font-size:0.8rem;margin-bottom:1rem;background:white;padding:0.75rem 1rem;border-radius:6px;border:1px solid #e0e0e0;">
      <span>Matched: <b>${totals.matched||0}</b></span>
      <span>Unmatched: <b>${totals.unmatched||0}</b></span>
      <span>Injected: <b>${totals.injected||0}</b></span>
      <span>Already linked: <b>${totals.already_linked||0}</b></span>
      <span>No module: <b>${totals.unresolved_mod||0}</b></span>
      <span>No service: <b>${totals.unresolved_svc||0}</b></span>
      <span style="margin-left:auto;color:#6a6a6a">${rows.length} rows shown</span>
    </div>` : '';

  const statusBadge = s => {
    const map = {
      'Added':            ['#d1ecf1','#0c5460'],
      'Already Linked':   ['#fff3cd','#856404'],
      'No Module Match':  ['#e2e3e5','#383d41'],
      'No Service Match': ['#fdecea','#c0392b'],
      'Module Not In Flat Index': ['#fdecea','#c0392b'],
    };
    const [bg, color] = map[s] || ['#e2e3e5','#383d41'];
    return `<span style="display:inline-block;padding:2px 8px;border-radius:12px;font-size:0.72rem;font-weight:600;background:${bg};color:${color}">${s||''}</span>`;
  };

  const rowsHtml = rows.length === 0 && !loading ? `
    <tr><td colspan="7" style="text-align:center;padding:2rem;color:#6a6a6a;">No records found</td></tr>` :
    rows.map(r => `
      <tr onclick="openDebugRow(${r.id})" style="cursor:pointer">
        <td style="font-size:0.78rem;color:#556B82;white-space:nowrap">${r.bs_code||''}</td>
        <td style="font-size:0.78rem;color:#6a6a6a;white-space:nowrap">${(r.crm_ids||'').substring(0,15)}</td>
        <td style="font-size:0.82rem;color:#1D2D3E">${r.deck_name||''}</td>
        <td style="font-size:0.82rem">${r.service_name||r.service_code||''}</td>
        <td style="font-size:0.78rem;color:#556B82">${r.module_name||r.module_code||''}</td>
        <td>${statusBadge(r.status)}</td>
        <td style="font-size:0.75rem;color:#6a6a6a">${r.service_code||''}</td>
      </tr>`).join('');

  return `
    ${state.debug.selectedRow ? (() => {
      const r = state.debug.selectedRow;
      const fields = [
        ['BS Code', r.bs_code], ['Type', r.type], ['Status', r.status],
        ['Service Code', r.service_code], ['Service Name', r.service_name],
        ['Module Code', r.module_code], ['Module Name', r.module_name],
        ['Deck Name', r.deck_name], ['CRM IDs', r.crm_ids],
        ['Created', r.created_at ? new Date(r.created_at).toLocaleString() : null],
      ].filter(([,v]) => v);
      const stepsHtml = (r.steps||[]).length > 0 ? `
        <h4 style="margin:1rem 0 0.5rem;font-size:0.85rem;color:#1D2D3E">Resolution Steps</h4>
        <table class="steps-table">
          <thead><tr><th>Type</th><th>Excel Value</th><th>DB Value</th><th>Method</th><th>Threshold</th><th>Result</th></tr></thead>
          <tbody>${(r.steps||[]).map(s => `
            <tr class="${s.result}">
              <td>${s.type||''}</td>
              <td style="max-width:180px;word-break:break-all">${s.excel_value||''}</td>
              <td style="max-width:180px;word-break:break-all">${s.db_value||''}</td>
              <td>${s.method||''}</td>
              <td>${s.threshold||''}</td>
              <td><b>${s.result||''}</b></td>
            </tr>`).join('')}
          </tbody>
        </table>` : '<p style="font-size:0.8rem;color:#6a6a6a;margin-top:0.5rem">No resolution steps recorded</p>';
      return `
        <div class="modal-overlay" onclick="if(event.target===this)closeDebugModal()">
          <div class="modal-box">
            <button class="modal-close" onclick="closeDebugModal()">&#x2715;</button>
            <h3 style="margin:0 0 1rem">${r.status} &mdash; ${(r.service_name||r.service_code||'').replace(/</g,'&lt;')}</h3>
            ${fields.map(([k,v]) => `<div style="display:flex;gap:0.5rem;margin-bottom:0.3rem;font-size:0.82rem"><span style="min-width:110px;color:#6a6a6a;font-weight:600">${k}</span><span>${String(v).replace(/</g,'&lt;')}</span></div>`).join('')}
            ${stepsHtml}
          </div>
        </div>`;
    })() : ''}
    <h2>Matching Debug</h2>
    <div class="filter-row" style="gap:1rem;flex-wrap:wrap;align-items:flex-end">
      <div style="display:flex;flex-direction:column;gap:4px;min-width:220px;max-width:320px">
        <label style="font-size:0.75rem;color:#6a6a6a;font-weight:600">Business Scenario</label>
        <select onchange="updateDebugFilter('bsCode',this.value)">
          <option value="">All business scenarios</option>
          ${bsOptions}
        </select>
      </div>
      <div style="display:flex;flex-direction:column;gap:4px;min-width:160px;max-width:240px">
        <label style="font-size:0.75rem;color:#6a6a6a;font-weight:600">Module (contains)</label>
        <input type="text" value="${module}" oninput="updateDebugFilter('module',this.value,true)" />
      </div>
      <div style="display:flex;flex-direction:column;gap:4px;min-width:160px;max-width:240px">
        <label style="font-size:0.75rem;color:#6a6a6a;font-weight:600">Deck / Service name (contains)</label>
        <input type="text" value="${serviceName}" oninput="updateDebugFilter('serviceName',this.value,true)" />
      </div>
      <div style="display:flex;flex-direction:column;gap:4px;min-width:160px;max-width:220px">
        <label style="font-size:0.75rem;color:#6a6a6a;font-weight:600">Status</label>
        <select onchange="updateDebugFilter('status',this.value)">
          ${statusOptions}
        </select>
      </div>
      ${loading ? `<div class="loading"><div class="loading-spinner"></div> Loading…</div>` : ''}
    </div>
    ${error ? `<div class="error-strip">Error: ${error.replace(/</g,'&lt;').replace(/>/g,'&gt;')}</div>` : ''}
    ${totalsHtml}
    <div style="overflow-x:auto">
      <table class="service-table">
        <thead>
          <tr>
            <th>BS Code</th>
            <th>Excel CRM ID</th>
            <th>Deck Name</th>
            <th>Service Name</th>
            <th>Module</th>
            <th>Status</th>
            <th>Code</th>
          </tr>
        </thead>
        <tbody>${rowsHtml}</tbody>
      </table>
    </div>`;
}

// ── Render ─────────────────────────────────────────────────────────────────────

window.openDebugRow = function(id) {
  const row = state.debug.rows.find(r => String(r.id) === String(id));
  if (row) { state.debug.selectedRow = row; render(); }
};
window.closeDebugModal = function() {
  state.debug.selectedRow = null; render();
};

window.closeAccessDenied = function() {
  state.accessDeniedModal = false; render();
};

window.openExportLogDetail = function(i) {
  state.exportLog.selectedRow = state.exportLog.rows[i] || null; render();
};

window.closeExportLogDetail = function() {
  state.exportLog.selectedRow = null; render();
};

window.loadExportLog = async function loadExportLog() {
  if (state.exportLog.loading) return;
  state.exportLog.loading = true; state.exportLog.error = null; render();
  try {
    const data = await apiFetch(`${CAP_BACKEND_URL}/api/catalog/export-log`);
    state.exportLog.rows = data.rows || [];
    state.exportLog.loaded = true;
  } catch (e) {
    state.exportLog.error = e.message;
  }
  state.exportLog.loading = false; render();
}

window.sortExportLog = function(col) {
  const el = state.exportLog;
  if (el.sortCol === col) { el.sortDir = el.sortDir === 'asc' ? 'desc' : 'asc'; }
  else { el.sortCol = col; el.sortDir = 'asc'; }
  render();
};

function renderExportLogPage() {
  const { rows, loading, error, loaded, sortCol, sortDir } = state.exportLog;
  if (loading) return `<div class="card"><div style="color:#6a6a6a;padding:2rem;text-align:center">Loading export log…</div></div>`;
  if (error) return `<div class="card"><div style="color:#dc3545;padding:1rem">Error: ${error}</div></div>`;
  if (!loaded) return `<div class="card"><div style="padding:1rem;color:#6a6a6a">No data yet.</div></div>`;
  if (rows.length === 0) return `<div class="card"><div style="padding:1rem;color:#6a6a6a">No export events recorded yet.</div></div>`;

  const fmt = iso => {
    const d = new Date(iso);
    return d.toLocaleString('en-GB', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit', second:'2-digit' });
  };

  const sorted = [...rows].sort((a, b) => {
    const av = a[sortCol] ?? '', bv = b[sortCol] ?? '';
    const cmp = (typeof av === 'number' && typeof bv === 'number')
      ? av - bv
      : String(av).localeCompare(String(bv));
    return sortDir === 'asc' ? cmp : -cmp;
  });

  const arrow = col => sortCol === col ? (sortDir === 'asc' ? ' ▲' : ' ▼') : ' ⇅';
  const th = (col, label, extra='') =>
    `<th style="cursor:pointer;user-select:none;white-space:nowrap${extra?';'+extra:''}" onclick="window.sortExportLog('${col}')">${label}<span style="opacity:0.5;font-size:0.7em">${arrow(col)}</span></th>`;

  return `
  <div class="card" style="overflow-x:auto">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem">
      <h3 style="margin:0;font-size:1rem">Export Log <span style="font-weight:400;color:#6a6a6a;font-size:0.875rem">(last 500 events)</span></h3>
      <button class="btn btn-secondary btn-sm" onclick="loadExportLog()">↻ Refresh</button>
    </div>
    <table class="service-table" style="font-size:0.8rem">
      <thead>
        <tr>
          ${th('logged_at',    'Date / Time')}
          ${th('logon_name',   'User')}
          ${th('export_type',  'Type')}
          ${th('service_count','#', 'text-align:center')}
          ${th('filter_bs',    'BS')}
          ${th('filter_et',    'ET')}
          ${th('filter_query', 'Query')}
        </tr>
      </thead>
      <tbody>
        ${sorted.map((r,i) => `<tr onclick="window.openExportLogDetail(${rows.indexOf(r)})" style="cursor:pointer">
          <td style="white-space:nowrap">${fmt(r.logged_at)}</td>
          <td style="white-space:nowrap">${r.logon_name || r.user_id || '—'}</td>
          <td>${r.export_type}</td>
          <td style="text-align:center">${r.service_count ?? '—'}</td>
          <td style="max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${r.filter_bs||''}">${r.filter_bs || '—'}</td>
          <td style="white-space:nowrap">${r.filter_et || '—'}</td>
          <td style="max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${r.filter_query||''}">${r.filter_query || '—'}</td>
        </tr>`).join('')}
      </tbody>
    </table>
  </div>`;
}

function renderExportLogDetailModal() {
  const r = state.exportLog.selectedRow;
  if (!r) return '';
  const fmt = iso => new Date(iso).toLocaleString('en-GB', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit', second:'2-digit' });
  const stream = r.pptx_stream_mode
    ? ((r.pptx_stream_mode === 'custom' || r.pptx_stream_mode === 'customNoBS')
        ? `${r.pptx_stream_mode}: "${r.pptx_stream_custom || ''}"` : r.pptx_stream_mode)
    : '—';
  const rows2 = [
    ['Date / Time',   fmt(r.logged_at)],
    ['User',          r.logon_name || r.user_id || '—'],
    ['Export Type',   r.export_type],
    ['# Services',    r.service_count ?? '—'],
    ['BS Filter',     r.filter_bs || '—'],
    ['ET Filter',     r.filter_et || '—'],
    ['Modules',       r.filter_modules?.length ? r.filter_modules.join(', ') : '—'],
    ['Query',         r.filter_query || '—'],
    ['Slide Title',   r.pptx_title || '—'],
    ['Stream Mode',   stream],
    ['Years',         r.pptx_year_from ? `${r.pptx_year_from} – ${r.pptx_year_to || '?'}` : '—'],
    ['Year Borders',  r.pptx_year_borders != null ? (r.pptx_year_borders ? 'Yes' : 'No') : '—'],
    ['Columns',       r.pptx_cols ? Object.entries(r.pptx_cols).filter(([,v])=>v).map(([k])=>k).join(', ') || '—' : '—'],
    ['Group by ET',   r.pptx_group_by_et   != null ? (r.pptx_group_by_et   ? 'Yes' : 'No') : '—'],
    ['Use Deck Name', r.pptx_use_deck_name != null ? (r.pptx_use_deck_name ? 'Yes' : 'No') : '—'],
    ['Truncate Obj',  r.pptx_truncate_obj  != null ? (r.pptx_truncate_obj  ? 'Yes' : 'No') : '—'],
  ];
  return `
  <div class="modal-overlay" onclick="if(event.target===this)window.closeExportLogDetail()">
    <div class="modal-box" style="max-width:480px" onclick="event.stopPropagation()">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem">
        <strong style="font-size:1rem">Export Details</strong>
        <button class="btn btn-secondary btn-sm" onclick="window.closeExportLogDetail()">✕</button>
      </div>
      <table style="width:100%;font-size:0.875rem;border-collapse:collapse">
        ${rows2.map(([k,v]) => `<tr>
          <td style="padding:0.3rem 0.75rem 0.3rem 0;color:#6a6a6a;white-space:nowrap;vertical-align:top;font-weight:600">${k}</td>
          <td style="padding:0.3rem 0;word-break:break-word">${v}</td>
        </tr>`).join('')}
      </table>
      <div style="margin-top:1.25rem;text-align:right"><button class="btn btn-primary" onclick="window.closeExportLogDetail()">Close</button></div>
    </div>
  </div>`;
}

// ── Admin handlers ────────────────────────────────────────────────────────────

async function loadAdminUsers() {
  state.admin.usersLoading = true; state.admin.usersError = null; render();
  try {
    const data = await apiFetch(`${CAP_BACKEND_URL}/api/catalog/admin/users`);
    state.admin.users = data.rows || [];
  } catch (e) { state.admin.usersError = e.message; }
  state.admin.usersLoading = false; render();
}

async function loadAdminVisitorLog() {
  state.admin.visitorLoading = true; state.admin.visitorError = null; render();
  try {
    const data = await apiFetch(`${CAP_BACKEND_URL}/api/catalog/admin/visitor-log`);
    state.admin.visitorLog = data.visits || [];
    state.admin.visitorLastSeen = data.lastSeen || [];
  } catch (e) { state.admin.visitorError = e.message; }
  state.admin.visitorLoading = false; render();
}

async function loadAdminMcpRequests() {
  state.admin.mcpRequestsLoading = true; state.admin.mcpRequestsError = null; render();
  try {
    const data = await apiFetch(`${CAP_BACKEND_URL}/api/catalog/admin/mcp-requests`);
    state.admin.mcpRequests = data.rows || [];
  } catch (e) { state.admin.mcpRequestsError = e.message; }
  state.admin.mcpRequestsLoading = false; render();
}

window.adminCloseMcpRequest = async function(id) {
  try {
    await apiFetch(`${CAP_BACKEND_URL}/api/catalog/admin/mcp-requests/close`, { method: 'POST', body: JSON.stringify({ id }) });
    await loadAdminMcpRequests();
  } catch (e) { state.admin.mcpRequestsError = e.message; render(); }
};

window.adminToggleMcpOpen = function() { state.admin.mcpOpenCollapsed = !state.admin.mcpOpenCollapsed; render(); };
window.adminSelectVisitorUser = function(email) {
  state.admin.selectedVisitorUser = state.admin.selectedVisitorUser === email ? null : email;
  render();
};
window.adminVisitSort = function(col) {
  const a = state.admin;
  if (a.visitSortCol === col) a.visitSortDir = a.visitSortDir === 'asc' ? 'desc' : 'asc';
  else { a.visitSortCol = col; a.visitSortDir = 'asc'; }
  render();
};
window.adminOpenVisit = function(idx) { state.admin.selectedVisit = { idx }; render(); };
window.adminCloseVisit = function() { state.admin.selectedVisit = null; render(); };

window.adminSetPerm = async function(email, tab, value) {
  const user = state.admin.users.find(u => u.email === email);
  if (!user) return;
  user[`tab_${tab}`] = value;
  render();
  try {
    await apiFetch(`${CAP_BACKEND_URL}/api/catalog/admin/users`, {
      method: 'POST',
      body: JSON.stringify({ email: user.email, tab_catalog: user.tab_catalog, tab_incidents: user.tab_incidents, tab_chat: user.tab_chat, tab_debug: user.tab_debug, tab_exportlog: user.tab_exportlog, tab_admin: user.tab_admin })
    });
  } catch (e) { state.admin.usersError = e.message; render(); }
};

window.adminEmailInput = function(v) {
  state.admin.newEmail = v;
};

window.adminAddUser = async function() {
  const email = (state.admin.newEmail || '').trim().toLowerCase();
  if (!email || !email.includes('@')) {
    state.admin.usersError = 'Enter a valid email address first';
    render();
    return;
  }
  state.admin.usersError = null;
  try {
    await apiFetch(`${CAP_BACKEND_URL}/api/catalog/admin/users`, {
      method: 'POST',
      body: JSON.stringify({ email, tab_catalog: true, tab_incidents: false, tab_chat: false, tab_debug: false, tab_exportlog: false, tab_admin: false })
    });
    state.admin.newEmail = '';
    await loadAdminUsers();
  } catch (e) { state.admin.usersError = e.message; render(); }
};

window.adminDeleteUser = async function(email) {
  if (!confirm(`Remove ${email}?`)) return;
  try {
    await apiFetch(`${CAP_BACKEND_URL}/api/catalog/admin/users/delete`, {
      method: 'POST',
      body: JSON.stringify({ email })
    });
    state.admin.users = state.admin.users.filter(u => u.email !== email);
    render();
  } catch (e) { state.admin.usersError = e.message; render(); }
};

function renderAdminPage() {
  const { users, usersLoading, usersError, newEmail, visitorLog, visitorLastSeen, visitorLoading, visitorError,
          mcpRequests, mcpRequestsLoading, mcpRequestsError, mcpOpenCollapsed, selectedVisitorUser,
          visitSortCol, visitSortDir, selectedVisit } = state.admin;
  const TABS = ['incidents','chat','debug','exportlog','admin'];
  const TAB_LABELS = { incidents:'Incidents', chat:'Chat', debug:'Debug', exportlog:'Export Log', admin:'Admin' };
  const fmtDate = iso => new Date(iso).toLocaleString('en-GB', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' });

  const sel = (email, tab, val) =>
    `<select style="font-size:0.75rem;padding:2px 4px;border:1px solid #ccc;border-radius:3px;background:${val?'#d4edda':'#f8d7da'}"
       onchange="window.adminSetPerm('${email}','${tab}',this.value==='true')">
       <option value="true" ${val?'selected':''}>Yes</option>
       <option value="false" ${val?'':'selected'}>No</option>
     </select>`;

  const openReqs   = mcpRequests.filter(r => r.status === 'open');
  const closedReqs = mcpRequests.filter(r => r.status === 'closed');
  const filteredVisits = (selectedVisitorUser
    ? visitorLog.filter(r => r.logon_name === selectedVisitorUser)
    : visitorLog
  ).slice().sort((a, b) => {
    const av = a[visitSortCol] || '', bv = b[visitSortCol] || '';
    return visitSortDir === 'asc' ? (av < bv ? -1 : av > bv ? 1 : 0) : (av > bv ? -1 : av < bv ? 1 : 0);
  });

  const colLeft = `
    <!-- User Permissions -->
    <div class="card" style="margin-bottom:1rem">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem">
        <h3 style="margin:0;font-size:1rem">User Permissions</h3>
        <button class="btn btn-secondary btn-sm" onclick="loadAdminUsers()">↻ Refresh</button>
      </div>
      ${usersError ? `<div class="error-strip">⚠ ${usersError}</div>` : ''}
      ${usersLoading ? `<div style="color:#6a6a6a;padding:1rem;text-align:center">Loading…</div>` : `
      <div style="overflow-x:auto">
        <table class="service-table" style="font-size:0.8rem;min-width:600px">
          <thead><tr>
            <th>Email</th>
            ${TABS.map(t => `<th style="text-align:center">${TAB_LABELS[t]}</th>`).join('')}
            <th></th>
          </tr></thead>
          <tbody>
            ${users.map(u => `<tr>
              <td style="white-space:nowrap">${u.email}</td>
              ${TABS.map(t => `<td style="text-align:center">${sel(u.email, t, u['tab_'+t])}</td>`).join('')}
              <td><button class="btn btn-secondary btn-sm" style="color:#dc3545" onclick="window.adminDeleteUser('${u.email}')">✕</button></td>
            </tr>`).join('')}
            <tr style="background:#f7f8f9">
              <td><input type="text" placeholder="new@email.com" value="${newEmail}"
                oninput="window.adminEmailInput(this.value)"
                style="width:100%;padding:0.3rem 0.5rem;font-size:0.8rem;border:1px solid #8696A9;border-radius:4px"
                onkeydown="if(event.key==='Enter')window.adminAddUser()"/></td>
              <td colspan="${TABS.length}"></td>
              <td><button class="btn btn-primary btn-sm" onclick="window.adminAddUser()">+ Add</button></td>
            </tr>
          </tbody>
        </table>
      </div>`}
    </div>

    <!-- Open MCP Requests -->
    <div class="card" style="margin-bottom:1rem">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:${mcpOpenCollapsed?'0':'1rem'}">
        <h3 style="margin:0;font-size:1rem">Open MCP Credentials Requests ${openReqs.length>0?`<span style="background:#dc3545;color:#fff;border-radius:10px;padding:1px 7px;font-size:0.72rem;font-weight:700;margin-left:6px">${openReqs.length}</span>`:''}</h3>
        <div style="display:flex;gap:0.5rem;align-items:center">
          <button class="btn btn-secondary btn-sm" onclick="loadAdminMcpRequests()">↻</button>
          <button class="btn btn-secondary btn-sm" onclick="window.adminToggleMcpOpen()" title="${mcpOpenCollapsed?'Expand':'Collapse'}">${mcpOpenCollapsed?'▶':'▼'}</button>
        </div>
      </div>
      ${mcpRequestsError ? `<div class="error-strip">⚠ ${mcpRequestsError}</div>` : ''}
      ${!mcpOpenCollapsed ? (mcpRequestsLoading ? `<div style="color:#6a6a6a;padding:0.5rem;text-align:center">Loading…</div>` : `
      <table class="service-table" style="font-size:0.8rem">
        <thead><tr><th>Email</th><th>Requested</th><th></th></tr></thead>
        <tbody>
          ${openReqs.map(r => `<tr>
            <td>${r.email}</td>
            <td style="white-space:nowrap">${fmtDate(r.requested_at)}</td>
            <td><button class="btn btn-secondary btn-sm" style="font-size:0.75rem" onclick="window.adminCloseMcpRequest(${r.id})">Close</button></td>
          </tr>`).join('') || '<tr><td colspan="3" style="color:#6a6a6a;text-align:center">No open requests</td></tr>'}
        </tbody>
      </table>`) : ''}
    </div>

    <!-- Closed MCP Requests -->
    <div class="card">
      <h3 style="margin:0 0 1rem;font-size:1rem">Closed MCP Credentials Requests</h3>
      ${mcpRequestsLoading ? `<div style="color:#6a6a6a;padding:0.5rem;text-align:center">Loading…</div>` : `
      <table class="service-table" style="font-size:0.8rem">
        <thead><tr><th>Email</th><th>Requested</th><th>Closed</th><th>By</th></tr></thead>
        <tbody>
          ${closedReqs.map(r => `<tr>
            <td>${r.email}</td>
            <td style="white-space:nowrap">${fmtDate(r.requested_at)}</td>
            <td style="white-space:nowrap">${r.closed_at ? fmtDate(r.closed_at) : '—'}</td>
            <td style="font-size:0.75rem;color:#6a6a6a">${r.closed_by || '—'}</td>
          </tr>`).join('') || '<tr><td colspan="4" style="color:#6a6a6a;text-align:center">No closed requests</td></tr>'}
        </tbody>
      </table>`}
    </div>`;

  const colRight = `
    <!-- Visitor Log -->
    <div class="card">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem">
        <h3 style="margin:0;font-size:1rem">Visitor Log</h3>
        <button class="btn btn-secondary btn-sm" onclick="loadAdminVisitorLog()">↻ Refresh</button>
      </div>
      ${visitorError ? `<div class="error-strip">⚠ ${visitorError}</div>` : ''}
      ${visitorLoading ? `<div style="color:#6a6a6a;padding:1rem;text-align:center">Loading…</div>` : `
      <div style="margin-bottom:1.5rem">
        <div style="font-weight:600;font-size:0.85rem;margin-bottom:0.5rem">Last Seen per User
          ${selectedVisitorUser ? `<button class="btn btn-secondary btn-sm" style="margin-left:0.75rem;font-size:0.72rem" onclick="window.adminSelectVisitorUser(null)">✕ Clear filter</button>` : ''}
        </div>
        <table class="service-table" style="font-size:0.8rem">
          <thead><tr><th>Email</th><th>Last Seen</th><th style="text-align:center">Total Visits</th></tr></thead>
          <tbody>
            ${visitorLastSeen.map(r => {
              const isSelected = selectedVisitorUser === r.logon_name;
              const isDimmed   = selectedVisitorUser && !isSelected;
              return `<tr style="cursor:pointer;${isSelected?'background:#d0e8f5;':''}${isDimmed?'color:#b0bec5;':''}"
                onclick="window.adminSelectVisitorUser('${r.logon_name.replace(/'/g,"\\'")}')">
                <td>${r.logon_name}</td>
                <td style="white-space:nowrap">${fmtDate(r.last_seen)}</td>
                <td style="text-align:center">${r.visit_count}</td>
              </tr>`;
            }).join('') || '<tr><td colspan="3" style="color:#6a6a6a;text-align:center">No visits yet</td></tr>'}
          </tbody>
        </table>
      </div>
      <div>
        <div style="font-weight:600;font-size:0.85rem;margin-bottom:0.5rem">
          Recent Page Visits (last 1000)${selectedVisitorUser ? ` — <span style="font-weight:400;color:#1D6FA4">${selectedVisitorUser}</span>` : ''}
        </div>
        <table class="service-table" style="font-size:0.8rem">
          <thead><tr>
            <th style="cursor:pointer;user-select:none" onclick="window.adminVisitSort('visited_at')">Date / Time ${visitSortCol==='visited_at'?(visitSortDir==='asc'?'▲':'▼'):''}</th>
            <th>Email</th>
            <th style="cursor:pointer;user-select:none" onclick="window.adminVisitSort('page')">Page ${visitSortCol==='page'?(visitSortDir==='asc'?'▲':'▼'):''}</th>
            <th>Session</th>
          </tr></thead>
          <tbody>
            ${filteredVisits.map((r, i) => `<tr style="cursor:${r.detail?'pointer':'default'}" onclick="${r.detail?`window.adminOpenVisit(${i})`:''}">
              <td style="white-space:nowrap">${fmtDate(r.visited_at)}</td>
              <td>${r.logon_name}</td>
              <td>${r.page || '—'}${r.detail ? ' <span style="font-size:0.65rem;color:#1D6FA4;vertical-align:middle">●</span>' : ''}</td>
              <td style="font-size:0.7rem;color:#6a6a6a">${r.session_id || '—'}</td>
            </tr>`).join('') || '<tr><td colspan="4" style="color:#6a6a6a;text-align:center">No visits yet</td></tr>'}
          </tbody>
        </table>
      </div>`}
    </div>`;

  const visitDetailPopup = selectedVisit ? (() => {
    const r = filteredVisits[selectedVisit.idx];
    if (!r) return '';
    const d = r.detail || {};
    return `
    <div class="modal-overlay" onclick="if(event.target===this)window.adminCloseVisit()">
      <div class="modal-box" style="max-width:520px">
        <button class="modal-close" onclick="window.adminCloseVisit()">✕</button>
        <h3 style="margin-top:0;font-size:1rem">MCP Tool Call Detail</h3>
        <div style="font-size:0.82rem;margin-bottom:0.5rem"><strong>Time:</strong> ${fmtDate(r.visited_at)}</div>
        <div style="font-size:0.82rem;margin-bottom:0.5rem"><strong>User:</strong> ${r.logon_name}</div>
        <div style="font-size:0.82rem;margin-bottom:0.75rem"><strong>Tool:</strong> ${d.tool || '—'}</div>
        ${d.args && Object.keys(d.args).length ? `
        <div style="font-size:0.82rem;font-weight:600;margin-bottom:0.4rem">Arguments:</div>
        <pre style="background:#f4f4f4;border-radius:4px;padding:0.75rem;font-size:0.75rem;overflow-x:auto;white-space:pre-wrap;word-break:break-all;max-height:320px;overflow-y:auto">${JSON.stringify(d.args, null, 2).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</pre>
        ` : '<div style="font-size:0.82rem;color:#6a6a6a">No arguments</div>'}
      </div>
    </div>`;
  })() : '';

  return `
  <style>
    .admin-grid { display:grid; grid-template-columns:1fr 1fr; gap:1rem; align-items:start; }
    @media (max-width:765px) { .admin-grid { grid-template-columns:1fr; } }
  </style>
  ${visitDetailPopup}
  <div class="admin-grid">
    <div>${colLeft}</div>
    <div>${colRight}</div>
  </div>`;
}


function renderMcpModal() {
  const m = state.mcpModal;
  if (!m.open) return '';
  const capabilities = [
    { name: 'Search Services',         desc: 'Find catalog services by keyword, engagement type, or business scenario' },
    { name: 'Get Service Details',     desc: 'Retrieve full details of any service by its code' },
    { name: 'List Business Scenarios', desc: 'Get the full list of available business scenarios with codes and names' },
    { name: 'Catalog Statistics',      desc: 'Fetch total service count and last catalog update timestamp' },
    { name: 'Generate Presentation',   desc: 'Build and download a PowerPoint list from any set of services' },
    { name: 'Custom PPTX Columns',     desc: 'Control which columns appear in the generated presentation', comingSoon: true },
  ];
  return `
  <div class="modal-overlay" onclick="if(event.target===this)window.closeMcpModal()">
    <div class="modal-box" style="max-width:560px">
      <button class="modal-close" onclick="window.closeMcpModal()">✕</button>
      <h3 style="margin-top:0;font-size:1.05rem">MCP for Joule Work Desktop</h3>
      <p style="font-size:0.875rem;color:#3a3a3a;line-height:1.55;margin:0 0 1rem">
        You can use the capabilities of this service via your Joule Work Desktop to create agents that utilise
        the following capabilities through MCP (Model Context Protocol):
      </p>
      <ul style="margin:0 0 1.25rem;padding-left:1.25rem;display:flex;flex-direction:column;gap:0.5rem">
        ${capabilities.map(c => `
        <li style="font-size:0.875rem;color:${c.comingSoon?'#8696A9':'#1D2D3E'}">
          <span style="font-weight:600">${c.name}</span>${c.comingSoon?' <span style="font-size:0.72rem;background:#e8f0f7;color:#1D6FA4;border-radius:3px;padding:1px 5px;vertical-align:middle">coming soon</span>':''}<br>
          <span style="color:#556B82;font-size:0.82rem">${c.desc}</span>
        </li>`).join('')}
      </ul>
      ${m.error ? `<div class="error-strip" style="margin-bottom:0.75rem">⚠ ${m.error}</div>` : ''}
      ${m.sent
        ? `<div style="background:#d4edda;color:#155724;border-radius:6px;padding:0.65rem 1rem;font-size:0.875rem;margin-bottom:0.75rem">
             ✓ Your request has been submitted. The administrator will follow up with you.
           </div>`
        : `<p style="font-size:0.875rem;color:#556B82;margin:0 0 1rem">
             Interested in connecting your JWD agents to this catalog?
           </p>`}
      <div style="display:flex;justify-content:flex-end;gap:0.75rem">
        <button class="btn btn-secondary btn-sm" onclick="window.closeMcpModal()">Close</button>
        ${!m.sent ? `<button class="btn btn-primary btn-sm" ${m.sending?'disabled':''} onclick="window.requestMcpAccess()">
          ${m.sending?'Sending…':'Request MCP Access'}
        </button>` : ''}
      </div>
    </div>
  </div>`;
}

window.openMcpModal  = function() { state.mcpModal = { open: true, sent: false, sending: false, error: null }; render(); };
window.closeMcpModal = function() { state.mcpModal.open = false; render(); };
window.requestMcpAccess = async function() {
  state.mcpModal.sending = true; state.mcpModal.error = null; render();
  try {
    await apiFetch(`${CAP_BACKEND_URL}/api/catalog/mcp-request`, { method: 'POST' });
    state.mcpModal.sent = true;
  } catch (e) { state.mcpModal.error = e.message; }
  state.mcpModal.sending = false; render();
};

function render() {
  const app = document.getElementById('app');
  if (!app) return;

  const allPages = [
    { id: 'catalog',   label: 'Catalogue Browser', perm: 'catalog' },
    { id: 'incidents', label: 'Incident Analysis',  perm: 'incidents' },
    { id: 'chat',      label: 'Chat',               perm: 'chat' },
    { id: 'debug',     label: 'Matching Debug',     perm: 'debug' },
    { id: 'exportlog', label: 'Export Log',         perm: 'exportlog' },
    { id: 'admin',     label: 'Admin',              perm: 'admin' },
  ];
  const pages = allPages.filter(p => state.myPermissions[p.perm]);

  let content = '';
  switch (state.currentPage) {
    case 'catalog':   content = renderCatalogPage(); break;
    case 'incidents': content = renderIncidentsPage(); break;
    case 'chat':      content = renderChatPage(); break;
    case 'debug':     content = renderDebugPage(); break;
    case 'exportlog': content = renderExportLogPage(); break;
    case 'admin':     content = renderAdminPage(); break;
    default:          content = renderCatalogPage();
  }

  // Preserve modal scroll position across re-renders
  const modalBox = document.querySelector('.modal-box');
  const modalScrollTop = modalBox ? modalBox.scrollTop : 0;

  app.innerHTML = `
    <div class="shell-top">
      <div class="shell-top-inner">
        <span class="shell-bar-title">Success Plans Catalogue Intelligence</span>
        <button class="btn btn-secondary btn-sm" onclick="window.openMcpModal()" style="margin-left:auto;font-size:0.8rem">MCP for JWD</button>
        <a href="mailto:aituar.aubakirov@sap.com?subject=SSC Intelligence Feedback" class="btn btn-secondary btn-sm" style="font-size:0.8rem">Feedback</a>
      </div>
    </div>
    <div class="shell-bar">
      <div class="shell-bar-inner">
        <nav class="shell-nav">
          ${pages.map(p => `<a href="#" class="shell-nav-item ${state.currentPage===p.id?'active':''}" onclick="navigate('${p.id}');return false">${p.label}</a>`).join('')}
        </nav>
        ${state.exportTotal != null ? `<span style="margin-left:auto;font-size:0.8rem;color:rgba(255,255,255,0.7)">Documents created: <strong style="color:#fff">${state.exportTotal}</strong></span>` : ''}
      </div>
    </div>
    <div class="page-content">${content}</div>
    ${renderServiceDetailModal()}
    ${renderPptxListSettingsModal()}
    ${renderExcelSettingsModal()}
    ${renderExportLogDetailModal()}
    ${renderMcpModal()}
    ${state.accessDeniedModal ? `
    <div class="modal-overlay" onclick="if(event.target===this)window.closeAccessDenied()">
      <div class="modal-box" style="max-width:420px">
        <strong style="font-size:1rem;display:block;margin-bottom:0.75rem">Access Restricted</strong>
        <p style="margin:0 0 0.75rem">This section is available to authorised users only.</p>
        <p style="margin:0 0 1.25rem;color:#6a6a6a;font-size:0.875rem">To request access, contact the app administrator:<br>
        <a href="mailto:aituar.aubakirov@sap.com">aituar.aubakirov@sap.com</a></p>
        <div style="text-align:right"><button class="btn btn-primary" onclick="window.closeAccessDenied()">OK</button></div>
      </div>
    </div>` : ''}
    ${state.backendDown ? `
    <div class="modal-overlay">
      <div class="modal-box" style="max-width:480px;text-align:center">
        <div style="font-size:2.5rem;margin-bottom:1rem">⚠️</div>
        <strong style="font-size:1.05rem;display:block;margin-bottom:0.75rem">Backend Unavailable</strong>
        <p style="margin:0 0 1.25rem;color:#555;font-size:0.95rem;line-height:1.5">
          We're experiencing some technical issues with the backend server.<br>
          The service may be restarting or temporarily down.
        </p>
        <button class="btn btn-primary" onclick="state.backendDown=false;loadCatalog()">Try Again</button>
      </div>
    </div>` : ''}`;
  // Restore modal scroll position
  if (modalScrollTop > 0) {
    const newModalBox = document.querySelector('.modal-box');
    if (newModalBox) newModalBox.scrollTop = modalScrollTop;
  }

  // Restore year input values without disturbing focus — the inputs use no value= attr
  const yf = document.getElementById('pptx-year-from');
  const yt = document.getElementById('pptx-year-to');
  if (yf && document.activeElement !== yf) yf.value = state.pptxListSettings.yearFrom;
  if (yt && document.activeElement !== yt) yt.value = state.pptxListSettings.yearTo;
  if (yf && !yf.value) yf.value = state.pptxListSettings.yearFrom;
  if (yt && !yt.value) yt.value = state.pptxListSettings.yearTo;

  // Fade out "Successfully downloaded" after 5s then clear state
  const dlMsg = document.getElementById('pptx-dl-msg');
  if (dlMsg) {
    clearTimeout(render._dlTimer);
    render._dlTimer = setTimeout(() => {
      const el = document.getElementById('pptx-dl-msg');
      if (!el) return;
      el.style.transition = 'opacity 0.8s';
      el.style.opacity = '0';
      setTimeout(() => { state.pptx.downloadUrl = null; render(); }, 800);
    }, 5000);
  }
}

// ── Boot ──────────────────────────────────────────────────────────────────────
render();
loadCatalog();
apiFetch(`${CAP_BACKEND_URL}/api/catalog/whoami`)
  .then(d => {
    state.currentUser = (d.logonName || '').toLowerCase();
    render();
  })
  .catch(() => {});
apiFetch(`${CAP_BACKEND_URL}/api/catalog/my-permissions`)
  .then(d => {
    state.myPermissions = { catalog: !!d.catalog, incidents: !!d.incidents, chat: !!d.chat, debug: !!d.debug, exportlog: !!d.exportlog, admin: !!d.admin };
    render();
  })
  .catch(() => {});
apiFetch(`${CAP_BACKEND_URL}/api/catalog/export-stats`)
  .then(d => { state.exportTotal = d.total ?? null; render(); })
  .catch(() => {});
// Log app load visit
apiFetch(`${CAP_BACKEND_URL}/api/catalog/visitor`, { method: 'POST', body: JSON.stringify({ page: 'app-load', sessionId: state.sessionId }) }).catch(() => {});

